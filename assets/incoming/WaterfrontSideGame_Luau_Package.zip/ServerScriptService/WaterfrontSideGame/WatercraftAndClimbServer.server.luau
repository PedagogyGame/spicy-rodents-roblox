--!strict
-- WatercraftAndClimbServer.server.luau
-- Watercraft spawning, unoccupied server wave buoyancy, stunt course validation,
-- StreamingEnabled distant island preloader, 3-point Hand/Foot climbing rig with
-- live segmented Belay Rope Beams, and E-key First-Person Waterfall Cliff Diving.

local CollectionService = game:GetService("CollectionService")
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
local Workspace = game:GetService("Workspace")

local sideGameFolder = ReplicatedStorage:WaitForChild("WaterfrontSideGame")
local WaterfrontConfig = require(sideGameFolder:WaitForChild("WaterfrontConfig"))
local OceanWaveSolver = require(sideGameFolder:WaitForChild("OceanWaveSolver"))

local remotes = sideGameFolder:WaitForChild("Remotes")
local vehicleEvent = remotes:WaitForChild("VehicleControlEvent") :: RemoteEvent
local climbingEvent = remotes:WaitForChild("ClimbingEvent") :: RemoteEvent
local stuntFeedbackEvent = remotes:WaitForChild("StuntFeedbackEvent") :: RemoteEvent
local waterfallDiveEvent = remotes:WaitForChild("WaterfallDiveEvent") :: RemoteEvent

local activeVehiclesFolder = Instance.new("Folder")
activeVehiclesFolder.Name = "ActiveWatercraft"
activeVehiclesFolder.Parent = Workspace

type ClimbSession = {
	RigFolder: Folder,
	AnchorPart: Part,
	HarnessAttachment: Attachment,
	LastRopeAttachment: Attachment,
	LastSafePos: Vector3,
	HandPos: Vector3,
	FootPos: Vector3,
	PitonsLeft: number,
}

local playerVehicles: { [Player]: Model } = {}
local climbSessions: { [Player]: ClimbSession } = {}
local activeDivers: { [Player]: number } = {}
local recentStuntHits: { [string]: number } = {}

--------------------------------------------------------------------------------
-- 1. WATERCRAFT SPAWNER & IDLE WAVE BUOYANCY
--------------------------------------------------------------------------------
local function weldPart(root: BasePart, part: BasePart)
	local wc = Instance.new("WeldConstraint")
	wc.Part0 = root
	wc.Part1 = part
	wc.Parent = part
end

local function addHullDetail(model: Model, root: BasePart, size: Vector3, relCF: CFrame, color: Color3, mat: Enum.Material): Part
	local p = Instance.new("Part")
	p.Size = size
	p.CFrame = root.CFrame * relCF
	p.Color = color
	p.Material = mat
	p.CanCollide = false
	p.Massless = true
	p.Parent = model
	weldPart(root, p)
	return p
end

local function spawnWatercraftForPlayer(player: Player, vehicleType: string, spawnWorldCF: CFrame)
	local old = playerVehicles[player]
	if old then
		old:Destroy()
		playerVehicles[player] = nil
	end

	local profile = WaterfrontConfig.VEHICLES[vehicleType]
	if not profile then
		return
	end

	local model = Instance.new("Model")
	model.Name = player.Name .. "_" .. vehicleType
	model:SetAttribute("VehicleType", vehicleType)
	model:SetAttribute("OwnerUserId", player.UserId)

	local hull = Instance.new("Part")
	hull.Name = "Hull"
	hull.Size = profile.HullSize
	hull.CFrame = spawnWorldCF
	hull.Color = profile.PrimaryColor
	hull.Material = Enum.Material.SmoothPlastic
	hull.CustomPhysicalProperties = PhysicalProperties.new(0.65, 0.1, 0.1, 1, 1)
	hull.Parent = model
	model.PrimaryPart = hull

	addHullDetail(model, hull, Vector3.new(profile.HullSize.X * 0.9, profile.HullSize.Y * 0.85, 3.6), CFrame.new(0, 0, -(profile.HullSize.Z * 0.5 + 1.4)), profile.PrimaryColor, Enum.Material.SmoothPlastic)
	addHullDetail(model, hull, Vector3.new(profile.HullSize.X * 1.04, 0.55, profile.HullSize.Z * 0.92), CFrame.new(0, -0.35, 0), profile.AccentColor, Enum.Material.SmoothPlastic)

	if vehicleType == "SpeedBoat" then
		addHullDetail(model, hull, Vector3.new(profile.HullSize.X * 0.82, 1.8, 3.2), CFrame.new(0, 2.2, -3.5) * CFrame.Angles(math.rad(-32), 0, 0), Color3.fromRGB(145, 210, 240), Enum.Material.Glass)
		addHullDetail(model, hull, Vector3.new(1.8, 2.8, 2.2), CFrame.new(-1.8, 0.4, profile.HullSize.Z * 0.5 + 1.0), Color3.fromRGB(32, 34, 38), Enum.Material.Metal)
		addHullDetail(model, hull, Vector3.new(1.8, 2.8, 2.2), CFrame.new(1.8, 0.4, profile.HullSize.Z * 0.5 + 1.0), Color3.fromRGB(32, 34, 38), Enum.Material.Metal)
	else
		addHullDetail(model, hull, Vector3.new(0.8, 2.2, 1.1), CFrame.new(0, 1.6, -1.6) * CFrame.Angles(math.rad(22), 0, 0), Color3.fromRGB(36, 38, 42), Enum.Material.Metal)
		addHullDetail(model, hull, Vector3.new(2.8, 0.35, 0.4), CFrame.new(0, 2.55, -1.2), Color3.fromRGB(24, 24, 26), Enum.Material.SmoothPlastic)
	end

	local rootAtt = Instance.new("Attachment")
	rootAtt.Name = "RootAttachment"
	rootAtt.Parent = hull

	local vf = Instance.new("VectorForce")
	vf.Name = "WaveAndThrustForce"
	vf.Attachment0 = rootAtt
	vf.RelativeTo = Enum.ActuatorRelativeTo.World
	vf.Force = Vector3.zero
	vf.Parent = hull

	local alignOri = Instance.new("AlignOrientation")
	alignOri.Name = "HullStabilizer"
	alignOri.Mode = Enum.OrientationAlignmentMode.OneAttachment
	alignOri.Attachment0 = rootAtt
	alignOri.Responsiveness = 18
	alignOri.MaxTorque = 850000
	alignOri.CFrame = spawnWorldCF.Rotation
	alignOri.Parent = hull

	local sternAtt = Instance.new("Attachment")
	sternAtt.Name = "SternWakeAttachment"
	sternAtt.Position = Vector3.new(0, -0.5, profile.HullSize.Z * 0.5)
	sternAtt.Parent = hull

	local wakeSpray = Instance.new("ParticleEmitter")
	wakeSpray.Name = "WakeSpray"
	wakeSpray.Rate = 0
	wakeSpray.Lifetime = NumberRange.new(0.5, 1.1)
	wakeSpray.Speed = NumberRange.new(8, 22)
	wakeSpray.SpreadAngle = Vector2.new(28, 18)
	wakeSpray.Size = NumberSequence.new({ NumberSequenceKeypoint.new(0, 1.4), NumberSequenceKeypoint.new(1, 5.8) })
	wakeSpray.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.25), NumberSequenceKeypoint.new(1, 1) })
	wakeSpray.Parent = sternAtt

	local seat = Instance.new("VehicleSeat")
	seat.Name = "DriverSeat"
	seat.Size = Vector3.new(2.2, 0.8, 2.2)
	seat.CFrame = hull.CFrame * CFrame.new(0, profile.HullSize.Y * 0.5 + 0.2, if vehicleType == "SpeedBoat" then -1.2 else 0.4)
	seat.HeadsUpDisplay = false
	seat.Transparency = 0.2
	seat.Color = Color3.fromRGB(32, 34, 38)
	seat.Disabled = true
	seat.Parent = model
	weldPart(hull, seat)

	local mountPrompt = Instance.new("ProximityPrompt")
	mountPrompt.Name = "MountPrompt"
	mountPrompt.ActionText = "Ride " .. profile.DisplayName
	mountPrompt.ObjectText = profile.DisplayName
	mountPrompt.KeyboardKeyCode = Enum.KeyCode.E
	mountPrompt.HoldDuration = 0
	mountPrompt.MaxActivationDistance = 12
	mountPrompt.Parent = hull

	mountPrompt.Triggered:Connect(function(triggerPlayer: Player)
		if seat.Occupant then
			return
		end
		local char = triggerPlayer.Character
		local hum = char and char:FindFirstChildOfClass("Humanoid")
		if hum and hum.Health > 0 then
			seat.Disabled = false
			seat:Sit(hum)
			mountPrompt.Enabled = false
			pcall(hull.SetNetworkOwner, hull, triggerPlayer)
		end
	end)

	seat:GetPropertyChangedSignal("Occupant"):Connect(function()
		if not seat.Occupant then
			seat.Disabled = true
			mountPrompt.Enabled = true
		end
	end)

	CollectionService:AddTag(model, "SimWatercraft")
	model.Parent = activeVehiclesFolder
	playerVehicles[player] = model

	local char = player.Character
	local hum = char and char:FindFirstChildOfClass("Humanoid")
	if hum and hum.Health > 0 then
		seat.Disabled = false
		seat:Sit(hum)
		mountPrompt.Enabled = false
		pcall(hull.SetNetworkOwner, hull, player)
	end
end

local function bindSpawner(kiosk: Instance)
	if not kiosk:IsA("BasePart") then
		return
	end
	local prompt = kiosk:FindFirstChildOfClass("ProximityPrompt")
	if prompt then
		prompt.Triggered:Connect(function(player: Player)
			local vType = kiosk:GetAttribute("VehicleType") :: string
			local localPos = kiosk:GetAttribute("SpawnLocalPos") :: Vector3
			local worldPos = WaterfrontConfig.localToWorld(localPos)
			local seaDir = WaterfrontConfig.getOriginCFrame().LookVector
			spawnWatercraftForPlayer(player, vType, CFrame.lookAt(worldPos, worldPos + seaDir))
		end)
	end
end

for _, k in CollectionService:GetTagged("WatercraftSpawner") do
	bindSpawner(k)
end
CollectionService:GetInstanceAddedSignal("WatercraftSpawner"):Connect(bindSpawner)

RunService.Heartbeat:Connect(function()
	local now = Workspace:GetServerTimeNow()
	for _, craft in activeVehiclesFolder:GetChildren() do
		if craft:IsA("Model") and craft.PrimaryPart then
			local seat = craft:FindFirstChild("DriverSeat") :: VehicleSeat?
			if seat and not seat.Occupant then
				local hull = craft.PrimaryPart
				local vf = hull:FindFirstChild("WaveAndThrustForce") :: VectorForce?
				local ao = hull:FindFirstChild("HullStabilizer") :: AlignOrientation?
				if vf and ao then
					local sample = OceanWaveSolver.sample(hull.Position.X, hull.Position.Z, now, 1)
					local depth = sample.height - hull.Position.Y
					local mass = hull.AssemblyMass
					local upward = mass * Workspace.Gravity + depth * mass * 42 - hull.AssemblyLinearVelocity.Y * mass * 6.5
					local horizDrag = -Vector3.new(hull.AssemblyLinearVelocity.X, 0, hull.AssemblyLinearVelocity.Z) * mass * 1.8
					vf.Force = Vector3.new(horizDrag.X, upward, horizDrag.Z)

					local forward = hull.CFrame.LookVector
					local right = forward:Cross(sample.normal)
					right = if right.Magnitude < 0.001 then Vector3.xAxis else right.Unit
					local adjustedForward = sample.normal:Cross(right).Unit
					ao.CFrame = CFrame.fromMatrix(Vector3.zero, right, sample.normal, -adjustedForward)
				end
			end
		end
	end
end)

--------------------------------------------------------------------------------
-- 2. STUNT GOALS & STREAMING-ENABLED DISTANT ISLAND PRELOADER
--------------------------------------------------------------------------------
local function bindStuntSensor(sensor: Instance)
	if not sensor:IsA("BasePart") then
		return
	end
	sensor.Touched:Connect(function(hit: BasePart)
		local model = hit:FindFirstAncestorOfClass("Model")
		if not model then
			return
		end
		local player = Players:GetPlayerFromCharacter(model)
		if not player and CollectionService:HasTag(model, "SimWatercraft") then
			local seat = model:FindFirstChild("DriverSeat") :: VehicleSeat?
			if seat and seat.Occupant and seat.Occupant.Parent then
				player = Players:GetPlayerFromCharacter(seat.Occupant.Parent)
			end
		end
		if not player then
			return
		end

		local stuntId = (sensor:GetAttribute("StuntId") :: string?) or sensor.Name
		local key = player.UserId .. "_" .. stuntId
		local now = os.clock()
		if recentStuntHits[key] and now - recentStuntHits[key] < 4.0 then
			return
		end
		recentStuntHits[key] = now

		local streaks = (player:GetAttribute("WaterStuntCount") :: number? or 0) + 1
		player:SetAttribute("WaterStuntCount", streaks)
		stuntFeedbackEvent:FireClient(player, (sensor:GetAttribute("StuntLabel") :: string?) or "STUNT CLEARED!", streaks)
	end)
end

for _, s in CollectionService:GetTagged("StuntGoalSensor") do
	bindStuntSensor(s)
end
CollectionService:GetInstanceAddedSignal("StuntGoalSensor"):Connect(bindStuntSensor)

task.spawn(function()
	while true do
		task.wait(1.5)
		if Workspace.StreamingEnabled then
			local smallWorld = WaterfrontConfig.localToWorld(WaterfrontConfig.SMALL_ISLAND.LOCAL_POS)
			local bigWorld = WaterfrontConfig.localToWorld(WaterfrontConfig.BIG_ISLAND.LOCAL_POS)
			for _, player in Players:GetPlayers() do
				local hrp = player.Character and player.Character:FindFirstChild("HumanoidRootPart") :: BasePart?
				if hrp then
					if (hrp.Position - smallWorld).Magnitude < WaterfrontConfig.SMALL_ISLAND.STREAM_PRELOAD_RADIUS then
						task.spawn(pcall, player.RequestStreamAroundAsync, player, smallWorld, 5)
					elseif (hrp.Position - bigWorld).Magnitude < WaterfrontConfig.BIG_ISLAND.STREAM_PRELOAD_RADIUS then
						task.spawn(pcall, player.RequestStreamAroundAsync, player, bigWorld, 5)
					end
				end
			end
		end
	end
end)

--------------------------------------------------------------------------------
-- 3. CLIMBING GEAR, BELAY ROPE CHAIN & 3-POINT HAND/FOOT RIG
--------------------------------------------------------------------------------
local function makeRopeBeam(parent: Instance, att0: Attachment, att1: Attachment): Beam
	local beam = Instance.new("Beam")
	beam.Attachment0 = att0
	beam.Attachment1 = att1
	beam.Width0 = 0.16
	beam.Width1 = 0.16
	beam.FaceCamera = true
	beam.Color = ColorSequence.new(Color3.fromRGB(228, 168, 58))
	beam.CurveSize0 = -1.2
	beam.Segments = 14
	beam.Parent = parent
	return beam
end

local function equipVisualHarness(player: Player)
	player:SetAttribute("HasClimbingHarness", true)
	local char = player.Character
	local torso = char and (char:FindFirstChild("UpperTorso") or char:FindFirstChild("Torso")) :: BasePart?
	if not torso or torso:FindFirstChild("MountaineerHarnessBelt") then
		return
	end

	local belt = Instance.new("Part")
	belt.Name = "MountaineerHarnessBelt"
	belt.Size = Vector3.new(2.15, 0.38, 1.15)
	belt.Color = Color3.fromRGB(54, 48, 42)
	belt.Material = Enum.Material.Fabric
	belt.CanCollide = false
	belt.Massless = true
	belt.CFrame = torso.CFrame * CFrame.new(0, -0.65, 0)
	belt.Parent = torso
	weldPart(torso, belt)

	local chalkBag = Instance.new("Part")
	chalkBag.Name = "ChalkBag"
	chalkBag.Size = Vector3.new(0.55, 0.72, 0.55)
	chalkBag.Color = Color3.fromRGB(185, 72, 54)
	chalkBag.Material = Enum.Material.Fabric
	chalkBag.CanCollide = false
	chalkBag.Massless = true
	chalkBag.CFrame = belt.CFrame * CFrame.new(0, 0.05, 0.72)
	chalkBag.Parent = belt
	weldPart(belt, chalkBag)
end

local function bindClimbChest(chest: Instance)
	local prompt = chest:FindFirstChildOfClass("ProximityPrompt")
	if prompt then
		prompt.Triggered:Connect(function(player: Player)
			equipVisualHarness(player)
			stuntFeedbackEvent:FireClient(player, "HARNESS, CHALK BAG & 5 PITONS EQUIPPED!", 0)
		end)
	end
end

for _, chest in CollectionService:GetTagged("ClimbingGearChest") do
	bindClimbChest(chest)
end
CollectionService:GetInstanceAddedSignal("ClimbingGearChest"):Connect(bindClimbChest)

local function computeBodyWallCFrame(handWorld: Vector3, footWorld: Vector3, wallNormalOut: Vector3): CFrame
	local midX = (handWorld.X * 0.6 + footWorld.X * 0.4)
	local midY = (handWorld.Y + footWorld.Y) * 0.5 + 0.35
	local midZ = (handWorld.Z + footWorld.Z) * 0.5
	local bodyPos = Vector3.new(midX, midY, midZ) + wallNormalOut * 1.95
	return CFrame.lookAt(bodyPos, bodyPos - wallNormalOut + Vector3.new(0, 0.12, 0))
end

local function bindClimbStart(startObj: Instance)
	if not startObj:IsA("BasePart") then
		return
	end
	local prompt = startObj:FindFirstChildOfClass("ProximityPrompt")
	if prompt then
		prompt.Triggered:Connect(function(player: Player)
			if not player:GetAttribute("HasClimbingHarness") then
				stuntFeedbackEvent:FireClient(player, "LOCKED: Search the pine side-trails for the old climbing chest!", 0)
				return
			end
			if climbSessions[player] then
				return
			end

			local char = player.Character
			local hrp = char and char:FindFirstChild("HumanoidRootPart") :: BasePart?
			local hum = char and char:FindFirstChildOfClass("Humanoid")
			if not hrp or not hum then
				return
			end

			hum.PlatformStand = true
			local wallOut = WaterfrontConfig.getOriginCFrame().LookVector * -1
			local initHand = startObj.Position + Vector3.new(0, 3.2, 0)
			local initFoot = startObj.Position + Vector3.new(0, -1.8, 0)
			local initCF = computeBodyWallCFrame(initHand, initFoot, wallOut)

			local rigFolder = Instance.new("Folder")
			rigFolder.Name = "ClimbSession_" .. player.Name
			rigFolder.Parent = Workspace

			local baseNode = Instance.new("Part")
			baseNode.Size = Vector3.new(0.4, 0.4, 0.4)
			baseNode.Anchored = true
			baseNode.CanCollide = false
			baseNode.Transparency = 1
			baseNode.CFrame = startObj.CFrame
			baseNode.Parent = rigFolder
			local baseAtt = Instance.new("Attachment", baseNode)

			local anchorPart = Instance.new("Part")
			anchorPart.Name = "ClimbBelayRig"
			anchorPart.Size = Vector3.new(1, 1, 1)
			anchorPart.Transparency = 1
			anchorPart.Anchored = true
			anchorPart.CanCollide = false
			anchorPart.CFrame = initCF
			anchorPart.Parent = rigFolder

			local harnessAtt = Instance.new("Attachment")
			harnessAtt.Position = Vector3.new(0, -0.6, 0.4)
			harnessAtt.Parent = anchorPart

			local activeLeadBeam = makeRopeBeam(rigFolder, baseAtt, harnessAtt)
			activeLeadBeam.Name = "ActiveLeadRope"

			hrp.CFrame = anchorPart.CFrame
			local weld = Instance.new("WeldConstraint")
			weld.Part0 = anchorPart
			weld.Part1 = hrp
			weld.Parent = anchorPart

			climbSessions[player] = {
				RigFolder = rigFolder,
				AnchorPart = anchorPart,
				HarnessAttachment = harnessAtt,
				LastRopeAttachment = baseAtt,
				LastSafePos = initCF.Position,
				HandPos = initHand,
				FootPos = initFoot,
				PitonsLeft = WaterfrontConfig.CLIMBING.STARTING_PITONS,
			}
			climbingEvent:FireClient(player, "BeginClimb", initHand, initFoot, WaterfrontConfig.CLIMBING.STARTING_PITONS)
		end)
	end
end

for _, startObj in CollectionService:GetTagged("ClimbStartTrigger") do
	bindClimbStart(startObj)
end
CollectionService:GetInstanceAddedSignal("ClimbStartTrigger"):Connect(bindClimbStart)

vehicleEvent.OnServerEvent:Connect(function(player: Player, action: string)
	if action == "Dismount" then
		local hum = player.Character and player.Character:FindFirstChildOfClass("Humanoid")
		if hum and hum.SeatPart then
			hum.Sit = false
		end
	end
end)

climbingEvent.OnServerEvent:Connect(function(player: Player, action: string, targetHold: Instance?)
	local session = climbSessions[player]
	if not session then
		return
	end
	local char = player.Character
	local hrp = char and char:FindFirstChild("HumanoidRootPart") :: BasePart?
	local hum = char and char:FindFirstChildOfClass("Humanoid")
	local wallOut = WaterfrontConfig.getOriginCFrame().LookVector * -1

	if (action == "PlaceHand" or action == "PlaceFoot") and targetHold and targetHold:IsA("BasePart") and CollectionService:HasTag(targetHold, "RockClimbHold") then
		if targetHold:GetAttribute("Broken") then
			return
		end
		local maxDist = if action == "PlaceHand" then WaterfrontConfig.CLIMBING.MAX_HAND_REACH + 3.5 else WaterfrontConfig.CLIMBING.MAX_FOOT_REACH + 3.5
		if (targetHold.Position - session.AnchorPart.Position).Magnitude > maxDist then
			return
		end

		if action == "PlaceHand" then
			if targetHold:GetAttribute("HoldType") == "FootChip" then
				return
			end
			session.HandPos = targetHold.Position
		else
			session.FootPos = targetHold.Position
		end

		local nextCF = computeBodyWallCFrame(session.HandPos, session.FootPos, wallOut)
		session.AnchorPart.CFrame = nextCF

		if targetHold:GetAttribute("HoldType") == "Ledge" then
			session.LastSafePos = nextCF.Position
			session.PitonsLeft = math.min(WaterfrontConfig.CLIMBING.STARTING_PITONS, session.PitonsLeft + 1)
		end

		if action == "PlaceHand" and targetHold:GetAttribute("IsTopOut") then
			session.RigFolder:Destroy()
			climbSessions[player] = nil
			if hum and hrp then
				hum.PlatformStand = false
				hrp.CFrame = CFrame.new(targetHold.Position + wallOut * -7 + Vector3.new(0, 5.5, 0))
			end
			climbingEvent:FireClient(player, "SummitReached")
			stuntFeedbackEvent:FireClient(player, "TRUE PINNACLE CONQUERED - 485 FT!", 0)
		end

	elseif action == "BreakLooseHold" and targetHold and targetHold:IsA("BasePart") then
		if targetHold:GetAttribute("HoldType") == "LooseRock" and not targetHold:GetAttribute("Broken") then
			targetHold:SetAttribute("Broken", true)
			targetHold.CanCollide = false
			targetHold.Transparency = 1
			task.delay(15, function()
				if targetHold.Parent then
					targetHold:SetAttribute("Broken", false)
					targetHold.Transparency = 0
					targetHold.CanCollide = true
				end
			end)
		end
		session.HandPos = session.LastSafePos + Vector3.new(0, 1.5, 0)
		session.FootPos = session.LastSafePos + Vector3.new(0, -2.5, 0)
		session.AnchorPart.CFrame = CFrame.lookAt(session.LastSafePos, session.LastSafePos - wallOut)

	elseif action == "PlacePiton" and targetHold and targetHold:IsA("BasePart") then
		if session.PitonsLeft > 0 and targetHold:GetAttribute("HoldType") == "PitonCrack" then
			session.PitonsLeft -= 1
			session.LastSafePos = session.AnchorPart.Position

			local pitonPart = Instance.new("Part")
			pitonPart.Name = "DrivenPiton"
			pitonPart.Size = Vector3.new(0.35, 0.35, 1.3)
			pitonPart.Color = Color3.fromRGB(220, 178, 72)
			pitonPart.Material = Enum.Material.Metal
			pitonPart.Anchored = true
			pitonPart.CanCollide = false
			pitonPart.CFrame = CFrame.new(targetHold.Position + wallOut * 0.55)
			pitonPart.Parent = session.RigFolder

			local newAtt = Instance.new("Attachment", pitonPart)
			makeRopeBeam(session.RigFolder, session.LastRopeAttachment, newAtt)
			local lead = session.RigFolder:FindFirstChild("ActiveLeadRope") :: Beam?
			if lead then
				lead.Attachment0 = newAtt
			end
			session.LastRopeAttachment = newAtt
			climbingEvent:FireClient(player, "PitonUpdated", session.LastSafePos, session.PitonsLeft)
		end

	elseif action == "FallToAnchor" then
		session.HandPos = session.LastSafePos + Vector3.new(0, 1.5, 0)
		session.FootPos = session.LastSafePos + Vector3.new(0, -2.5, 0)
		session.AnchorPart.CFrame = CFrame.lookAt(session.LastSafePos, session.LastSafePos - wallOut)

	elseif action == "ExitClimb" then
		local safeDrop = session.LastSafePos + wallOut * 4.2 + Vector3.new(0, 2.0, 0)
		session.RigFolder:Destroy()
		climbSessions[player] = nil
		if hum and hrp then
			hum.PlatformStand = false
			hrp.CFrame = CFrame.new(safeDrop)
		end
		climbingEvent:FireClient(player, "ClimbExited")
	end
end)

--------------------------------------------------------------------------------
-- 4. FIRST-PERSON WATERFALL CLIFF DIVE SERVER HANDLER (E KEY JUMP)
--------------------------------------------------------------------------------
local function bindDiveLedge(ledge: Instance)
	if not ledge:IsA("BasePart") then
		return
	end
	local prompt = ledge:FindFirstChildOfClass("ProximityPrompt")
	if not prompt then
		return
	end

	prompt.Triggered:Connect(function(player: Player)
		if climbSessions[player] then
			return
		end
		local now = os.clock()
		if activeDivers[player] and now - activeDivers[player] < 4.5 then
			return
		end

		local char = player.Character
		local hum = char and char:FindFirstChildOfClass("Humanoid")
		local hrp = char and char:FindFirstChild("HumanoidRootPart") :: BasePart?
		if not hum or not hrp or hum.Health <= 0 or hum.SeatPart then
			return
		end

		activeDivers[player] = now
		hum:SetStateEnabled(Enum.HumanoidStateType.FallingDown, false)
		hum:SetStateEnabled(Enum.HumanoidStateType.Ragdoll, false)

		local payload = {
			StartPos = ledge.Position,
			ForwardDir = (ledge:GetAttribute("ForwardDir") :: Vector3?) or Vector3.zAxis,
			TargetWaterY = (ledge:GetAttribute("TargetWaterY") :: number?) or 2,
			PoolDepth = (ledge:GetAttribute("PoolDepth") :: number?) or 16,
			DiveName = (ledge:GetAttribute("DiveName") :: string?) or "Waterfall Crest",
		}
		waterfallDiveEvent:FireClient(player, "StartWaterfallDive", payload)
	end)
end

for _, ledge in CollectionService:GetTagged("WaterfallDiveLedge") do
	bindDiveLedge(ledge)
end
CollectionService:GetInstanceAddedSignal("WaterfallDiveLedge"):Connect(bindDiveLedge)

waterfallDiveEvent.OnServerEvent:Connect(function(player: Player, action: string, splashWorldPos: Vector3?)
	if action == "SplashdownImpact" and typeof(splashWorldPos) == "Vector3" then
		local splashAnchor = Instance.new("Part")
		splashAnchor.Size = Vector3.new(2, 1, 2)
		splashAnchor.Anchored = true
		splashAnchor.CanCollide = false
		splashAnchor.Transparency = 1
		splashAnchor.Position = splashWorldPos
		splashAnchor.Parent = Workspace

		local plume = Instance.new("ParticleEmitter")
		plume.Speed = NumberRange.new(26, 52)
		plume.Lifetime = NumberRange.new(0.65, 1.25)
		plume.SpreadAngle = Vector2.new(24, 24)
		plume.Acceleration = Vector3.new(0, -68, 0)
		plume.Size = NumberSequence.new({ NumberSequenceKeypoint.new(0, 3.2), NumberSequenceKeypoint.new(1, 9.5) })
		plume.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.15), NumberSequenceKeypoint.new(1, 1) })
		plume.Color = ColorSequence.new(Color3.fromRGB(235, 248, 255))
		plume.Rate = 0
		plume.Parent = splashAnchor
		plume:Emit(55)

		task.delay(1.8, function()
			splashAnchor:Destroy()
		end)
	elseif action == "CompleteDive" then
		activeDivers[player] = nil
		local hum = player.Character and player.Character:FindFirstChildOfClass("Humanoid")
		if hum then
			hum:SetStateEnabled(Enum.HumanoidStateType.FallingDown, true)
			hum:SetStateEnabled(Enum.HumanoidStateType.Ragdoll, true)
		end
	end
end)

Players.PlayerRemoving:Connect(function(player: Player)
	activeDivers[player] = nil
	if playerVehicles[player] then
		playerVehicles[player]:Destroy()
		playerVehicles[player] = nil
	end
	if climbSessions[player] then
		climbSessions[player].RigFolder:Destroy()
		climbSessions[player] = nil
	end
end)
