--!strict
-- WaterfrontWorldBuilder.server.luau
-- Generates Marina Dock, Utah Sandstone Cliffs/Arches/Hoodoos/Sea Caves, Stunt Ramps & Protruding Rocks,
-- Small Coconut Island, and the Asymmetric Big Cliff Island (Smuggler's Cove, Dual Waterfalls,
-- Articulated Rush-By Cliff-Dive Chutes, Carved 18-Stud Plunge Pool, Streams, 7-Stage Non-Spiral Trail,
-- Hidden Mountaineer's Chest, Main Lookout, and 22-Tier 3-Route Upper-Quarter Sheer Climbing Monolith).

local CollectionService = game:GetService("CollectionService")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Workspace = game:GetService("Workspace")

local sideGameFolder = ReplicatedStorage:WaitForChild("WaterfrontSideGame")
local WaterfrontConfig = require(sideGameFolder:WaitForChild("WaterfrontConfig"))

local remotesFolderInstance: Folder
local existingRemotes = sideGameFolder:FindFirstChild("Remotes")
if existingRemotes and existingRemotes:IsA("Folder") then
	remotesFolderInstance = existingRemotes
else
	local f = Instance.new("Folder")
	f.Name = "Remotes"
	f.Parent = sideGameFolder
	remotesFolderInstance = f
end

local function ensureRemote(name: string): RemoteEvent
	local existing = remotesFolderInstance:FindFirstChild(name)
	if existing and existing:IsA("RemoteEvent") then
		return existing
	end
	local re = Instance.new("RemoteEvent")
	re.Name = name
	re.Parent = remotesFolderInstance
	return re
end

ensureRemote("VehicleControlEvent")
ensureRemote("ClimbingEvent")
ensureRemote("StuntFeedbackEvent")
ensureRemote("WaterfallDiveEvent")

local worldRoot = Instance.new("Folder")
worldRoot.Name = "WaterfrontSideGameWorld"
worldRoot.Parent = Workspace

local nearShoreFolder = Instance.new("Folder")
nearShoreFolder.Name = "NearShoreStructures"
nearShoreFolder.Parent = worldRoot

local distantIslandsFolder = Instance.new("Folder")
distantIslandsFolder.Name = "DistantIslands"
distantIslandsFolder.Parent = worldRoot

local stuntCourseFolder = Instance.new("Folder")
stuntCourseFolder.Name = "StuntCourse"
stuntCourseFolder.Parent = worldRoot

local function makeLocalPart(
	parent: Instance,
	name: string,
	size: Vector3,
	localCF: CFrame,
	color: Color3,
	material: Enum.Material,
	canCollide: boolean?
): Part
	local p = Instance.new("Part")
	p.Name = name
	p.Size = size
	p.CFrame = WaterfrontConfig.localCFrameToWorld(localCF)
	p.Anchored = true
	p.CanCollide = if canCollide == nil then true else canCollide
	p.Color = color
	p.Material = material
	p.TopSurface = Enum.SurfaceType.Smooth
	p.BottomSurface = Enum.SurfaceType.Smooth
	p.Parent = parent
	return p
end

local function makeLocalWedge(
	parent: Instance,
	name: string,
	size: Vector3,
	localCF: CFrame,
	color: Color3,
	material: Enum.Material
): WedgePart
	local w = Instance.new("WedgePart")
	w.Name = name
	w.Size = size
	w.CFrame = WaterfrontConfig.localCFrameToWorld(localCF)
	w.Anchored = true
	w.Color = color
	w.Material = material
	w.Parent = parent
	return w
end

--------------------------------------------------------------------------------
-- 1. MARINA DOCK & OUTER SHORELINE REEF
--------------------------------------------------------------------------------
local function buildMarinaDock()
	local dockModel = Instance.new("Model")
	dockModel.Name = "WatercraftSimulatorDock"
	dockModel.Parent = nearShoreFolder

	local woodColor = Color3.fromRGB(132, 94, 62)
	local darkWood = Color3.fromRGB(82, 56, 36)

	makeLocalPart(dockModel, "MainPierDeck", Vector3.new(18, 1.2, 130), CFrame.new(0, 3.2, -65), woodColor, Enum.Material.WoodPlanks)
	makeLocalPart(dockModel, "CrossPierDeck", Vector3.new(96, 1.2, 16), CFrame.new(0, 3.2, -132), woodColor, Enum.Material.WoodPlanks)

	for z = -10, -125, -23 do
		for _, x in { -8, 8 } do
			makeLocalPart(dockModel, "Piling", Vector3.new(2.0, 22, 2.0), CFrame.new(x, -3.5, z), darkWood, Enum.Material.Wood)
		end
	end
	for x = -44, 44, 22 do
		for _, z in { -125, -139 } do
			makeLocalPart(dockModel, "CrossPiling", Vector3.new(2.2, 24, 2.2), CFrame.new(x, -3.5, z), darkWood, Enum.Material.Wood)
			local lantern = makeLocalPart(dockModel, "LanternGlass", Vector3.new(1.2, 1.4, 1.2), CFrame.new(x, 9.2, z), Color3.fromRGB(255, 214, 142), Enum.Material.Neon, false)
			local light = Instance.new("PointLight")
			light.Color = Color3.fromRGB(255, 205, 130)
			light.Range = 24
			light.Brightness = 1.2
			light.Parent = lantern
		end
	end

	local slips = {
		{ VehicleType = "JetSki",     X = -34, Label = "Spawn Stunt Jet Ski" },
		{ VehicleType = "WaveRunner", X = 0,   Label = "Spawn Ocean WaveRunner" },
		{ VehicleType = "SpeedBoat",  X = 36,  Label = "Spawn Offshore Speedboat" },
	}
	for _, slip in slips do
		makeLocalPart(dockModel, "FingerPier_" .. slip.VehicleType, Vector3.new(8, 1.1, 28), CFrame.new(slip.X - 9, 3.0, -154), woodColor, Enum.Material.WoodPlanks)
		makeLocalPart(dockModel, "Bumper", Vector3.new(0.8, 1.4, 26), CFrame.new(slip.X - 4.8, 2.9, -154), Color3.fromRGB(35, 38, 42), Enum.Material.SmoothPlastic)

		local kiosk = makeLocalPart(dockModel, "SpawnKiosk_" .. slip.VehicleType, Vector3.new(2.6, 4.4, 1.8), CFrame.new(slip.X - 9, 5.8, -142), Color3.fromRGB(62, 66, 72), Enum.Material.Metal)
		kiosk:SetAttribute("VehicleType", slip.VehicleType)
		kiosk:SetAttribute("SpawnLocalPos", Vector3.new(slip.X + 2, 1.5, -158))
		CollectionService:AddTag(kiosk, "WatercraftSpawner")

		local prompt = Instance.new("ProximityPrompt")
		prompt.ActionText = slip.Label
		prompt.ObjectText = "Marina Slip"
		prompt.KeyboardKeyCode = Enum.KeyCode.E
		prompt.HoldDuration = 0.2
		prompt.MaxActivationDistance = 12
		prompt.Parent = kiosk
	end

	local rng = Random.new(4041)
	local halfW = WaterfrontConfig.BREAKWATER_HALF_WIDTH
	for side = -1, 1, 2 do
		for i = 1, 26 do
			local x = side * (halfW + 5 + i * 26 + rng:NextNumber(-8, 8))
			local z = WaterfrontConfig.getOuterShorelineZ(x) + rng:NextNumber(-55, 25)
			local s = Vector3.new(rng:NextNumber(14, 34), rng:NextNumber(6, 16), rng:NextNumber(14, 32))
			makeLocalPart(
				nearShoreFolder,
				"ShorelineReefRock",
				s,
				CFrame.new(x, s.Y * 0.22 - 2, z) * CFrame.Angles(rng:NextNumber(-0.2, 0.2), rng:NextNumber(0, 6.28), rng:NextNumber(-0.2, 0.2)),
				Color3.fromRGB(118, 114, 108),
				Enum.Material.Slate
			)
		end
	end
end

--------------------------------------------------------------------------------
-- 2. UTAH SANDSTONE CLIFFS, ARCHES, HOODOOS & VAULTED SEA CAVES
--------------------------------------------------------------------------------
local UTAH_STRATA = {
	Color3.fromRGB(192, 92, 54),
	Color3.fromRGB(214, 126, 74),
	Color3.fromRGB(158, 68, 44),
	Color3.fromRGB(224, 164, 112),
}

local function buildUtahArch(parent: Instance, centerLocal: Vector3, span: number, height: number, yawRad: number)
	local archModel = Instance.new("Model")
	archModel.Name = "UtahSandstoneArch"
	archModel.Parent = parent

	local segments = 13
	for i = 0, segments do
		local angle = math.pi * (i / segments)
		local segLength = (math.pi * span * 0.55) / segments + 4
		local thickness = 14 - math.sin(angle) * 4.5
		local segCF = CFrame.new(centerLocal) * CFrame.Angles(0, yawRad, 0)
			* CFrame.new(-math.cos(angle) * (span * 0.5), math.sin(angle) * height, 0)
			* CFrame.Angles(0, 0, angle - math.pi * 0.5)
		makeLocalPart(archModel, "ArchSpan", Vector3.new(segLength, thickness, thickness * 1.15), segCF, UTAH_STRATA[(i % #UTAH_STRATA) + 1], Enum.Material.Sandstone)
	end
end

local function buildUtahHoodoo(parent: Instance, basePos: Vector3, totalH: number, seed: number)
	local rng = Random.new(seed)
	local yCursor = -6
	local stepH = (totalH + 6) / 8
	for l = 1, 8 do
		local widthMult = if l == 7 then 0.56 elseif l == 8 then 1.20 else (1.15 - l * 0.06 + rng:NextNumber(-0.14, 0.14))
		local w = math.max(7, totalH * 0.24 * widthMult)
		makeLocalPart(
			parent,
			"UtahHoodooLayer",
			Vector3.new(w, stepH + 1.2, w * rng:NextNumber(0.85, 1.15)),
			CFrame.new(basePos.X + rng:NextNumber(-1.5, 1.5), yCursor + stepH * 0.5, basePos.Z + rng:NextNumber(-1.5, 1.5))
				* CFrame.Angles(rng:NextNumber(-0.06, 0.06), rng:NextNumber(0, 6.28), rng:NextNumber(-0.06, 0.06)),
			UTAH_STRATA[((l + seed) % #UTAH_STRATA) + 1],
			Enum.Material.Sandstone
		)
		yCursor += stepH
	end
end

local function buildSeaCaveHeadland(parent: Instance, side: number)
	local headland = Instance.new("Model")
	headland.Name = if side < 0 then "UtahHeadland_West" else "UtahHeadland_East"
	headland.Parent = parent

	local rng = Random.new(if side < 0 then 9101 else 9202)
	local startX = side * (WaterfrontConfig.BREAKWATER_HALF_WIDTH + 90)

	for step = 0, 14 do
		local t = step / 14
		local cx = startX + side * (math.sin(t * 2.7) * 240 + t * 340)
		local cz = 90 - t * 1380
		local cliffH = 68 + math.sin(t * 3.8) * 34 + rng:NextNumber(0, 22)

		if step == 6 or step == 7 or step == 11 then
			local centerCF = CFrame.new(cx, 0, cz) * CFrame.Angles(0, side * 0.35, 0)
			makeLocalPart(headland, "SeaCaveWallA", Vector3.new(28, cliffH, 92), centerCF * CFrame.new(-34, cliffH * 0.42, 0), UTAH_STRATA[1], Enum.Material.Sandstone)
			makeLocalPart(headland, "SeaCaveWallB", Vector3.new(28, cliffH, 92), centerCF * CFrame.new(34, cliffH * 0.42, 0), UTAH_STRATA[3], Enum.Material.Sandstone)
			makeLocalPart(headland, "SeaCaveCeiling", Vector3.new(98, 28, 96), centerCF * CFrame.new(0, 34, 0), UTAH_STRATA[2], Enum.Material.Sandstone)
			makeLocalPart(headland, "SeaCaveOverhang", Vector3.new(76, 22, 74), centerCF * CFrame.new(side * 8, 54, 0) * CFrame.Angles(0.08, 0.2, -0.06), UTAH_STRATA[4], Enum.Material.Sandstone)

			local glowAnchor = makeLocalPart(headland, "CaveWaterBounce", Vector3.new(2, 1, 2), centerCF * CFrame.new(0, 18, 0), UTAH_STRATA[2], Enum.Material.Sandstone, false)
			glowAnchor.Transparency = 1
			local caveLight = Instance.new("PointLight")
			caveLight.Color = Color3.fromRGB(72, 195, 215)
			caveLight.Range = 55
			caveLight.Brightness = 1.4
			caveLight.Parent = glowAnchor
		else
			for tier = 1, 4 do
				local tierH = cliffH / 4
				local w = 115 - tier * 14 + rng:NextNumber(-10, 16)
				makeLocalPart(
					headland,
					"UtahCliffStrata",
					Vector3.new(w, tierH + 3, 112),
					CFrame.new(cx + rng:NextNumber(-14, 14), (tier - 0.5) * tierH - 6, cz)
						* CFrame.Angles(rng:NextNumber(-0.08, 0.08), rng:NextNumber(0, 3.14), rng:NextNumber(-0.1, 0.1)),
					UTAH_STRATA[((step + tier) % #UTAH_STRATA) + 1],
					Enum.Material.Sandstone
				)
			end
		end
	end

	buildUtahArch(headland, Vector3.new(startX + side * 490, -2, -980), 96, 46, side * 0.55)
	buildUtahArch(headland, Vector3.new(startX + side * 620, -2, -1340), 82, 38, -side * 0.4)
	for h = 1, 7 do
		buildUtahHoodoo(headland, Vector3.new(startX + side * (380 + h * 75 + rng:NextNumber(-30, 30)), 0, -480 - h * 145 + rng:NextNumber(-45, 45)), rng:NextNumber(42, 78), h * 31 + (if side < 0 then 1 else 2))
	end
end

--------------------------------------------------------------------------------
-- 3. STUNT RAMPS, CHALLENGING RINGS & PROTRUDING ROCK JUMPS
--------------------------------------------------------------------------------
local function buildFloatingRamp(parent: Instance, name: string, pos: Vector3, yawDeg: number, length: number, width: number, angleDeg: number)
	local rampModel = Instance.new("Model")
	rampModel.Name = name
	rampModel.Parent = parent

	local pitchRad = math.rad(angleDeg)
	local baseCF = CFrame.new(pos.X, 0.4, pos.Z) * CFrame.Angles(0, math.rad(yawDeg), 0)
	for _, sideX in { -(width * 0.42), width * 0.42 } do
		makeLocalPart(rampModel, "Pontoon", Vector3.new(2.6, 3.2, length * 0.92), baseCF * CFrame.new(sideX, -0.8, 0), Color3.fromRGB(45, 48, 54), Enum.Material.Metal)
	end

	local rise = math.sin(pitchRad) * length
	local deckCF = baseCF * CFrame.new(0, rise * 0.42 - 1.2, 0) * CFrame.Angles(pitchRad, 0, 0)
	local deck = makeLocalPart(rampModel, "LaunchDeck", Vector3.new(width, 1.2, length), deckCF, Color3.fromRGB(228, 124, 34), Enum.Material.DiamondPlate)
	CollectionService:AddTag(deck, "StuntLaunchRamp")

	for _, sideX in { -(width * 0.48), width * 0.48 } do
		makeLocalPart(rampModel, "RampRail", Vector3.new(0.7, 1.6, length), deckCF * CFrame.new(sideX, 0.9, 0), Color3.fromRGB(245, 212, 56), Enum.Material.SmoothPlastic, false)
	end
end

local function buildStuntRing(parent: Instance, stuntId: string, centerLocal: Vector3, radius: number, yawDeg: number)
	local ringModel = Instance.new("Model")
	ringModel.Name = stuntId
	ringModel.Parent = parent

	local baseCF = CFrame.new(centerLocal) * CFrame.Angles(0, math.rad(yawDeg), 0)
	for i = 1, 16 do
		local a = (i / 16) * math.pi * 2
		local segLen = (2 * math.pi * radius) / 16 + 0.35
		makeLocalPart(ringModel, "RingRim", Vector3.new(0.95, segLen, 0.95), baseCF * CFrame.new(math.cos(a) * radius, math.sin(a) * radius, 0) * CFrame.Angles(0, 0, a), Color3.fromRGB(255, 168, 36), Enum.Material.Neon, false)
	end

	local sensor = makeLocalPart(ringModel, "RingSensor", Vector3.new(radius * 1.65, radius * 1.65, 3.2), baseCF, Color3.new(1, 1, 1), Enum.Material.SmoothPlastic, false)
	sensor.Transparency = 1
	sensor:SetAttribute("StuntId", stuntId)
	sensor:SetAttribute("StuntLabel", "STUNT RING CLEARED!")
	CollectionService:AddTag(sensor, "StuntGoalSensor")
end

local function buildStuntCourse()
	for _, spec in WaterfrontConfig.RING_STUNTS do
		buildFloatingRamp(stuntCourseFolder, "Ramp_" .. spec.Id, spec.RampPos, spec.YawDeg, spec.RampLength, 14, spec.RampAngleDeg)
		local forward = CFrame.Angles(0, math.rad(spec.YawDeg), 0).LookVector
		buildStuntRing(stuntCourseFolder, spec.Id, spec.RampPos + forward * spec.RingDist + Vector3.new(0, spec.RingHeight, 0), spec.RingRadius, spec.YawDeg)
	end

	for idx, rockSpec in WaterfrontConfig.ROCK_JUMPS do
		local rockModel = Instance.new("Model")
		rockModel.Name = rockSpec.Id
		rockModel.Parent = stuntCourseFolder

		local rng = Random.new(700 + idx)
		for _ = 1, 7 do
			local h = rockSpec.RockHeight * rng:NextNumber(0.55, 1.05)
			local w = rockSpec.RockWidth * rng:NextNumber(0.38, 0.68)
			makeLocalPart(
				rockModel,
				"ProtrudingRockSpire",
				Vector3.new(w, h, w * 0.85),
				CFrame.new(rockSpec.RockPos + Vector3.new(rng:NextNumber(-rockSpec.RockWidth * 0.28, rockSpec.RockWidth * 0.28), h * 0.38 - 5, rng:NextNumber(-8, 8)))
					* CFrame.Angles(rng:NextNumber(-0.22, 0.22), rng:NextNumber(0, 6.28), rng:NextNumber(-0.22, 0.22)),
				Color3.fromRGB(92, 88, 84),
				Enum.Material.Slate
			)
		end

		buildFloatingRamp(rockModel, "RockJumpRamp_" .. rockSpec.Id, rockSpec.RockPos + rockSpec.RampOffset, rockSpec.RampYawDeg, 44, 13, rockSpec.RampAngleDeg)
		local apexSensor = makeLocalPart(rockModel, "RockApexSensor", Vector3.new(rockSpec.RockWidth * 1.1, 18, 12), CFrame.new(rockSpec.RockPos + Vector3.new(0, rockSpec.RockHeight + 8, 0)), Color3.new(1, 1, 1), Enum.Material.SmoothPlastic, false)
		apexSensor.Transparency = 1
		apexSensor:SetAttribute("StuntId", rockSpec.Id)
		apexSensor:SetAttribute("StuntLabel", "JAGGED ROCK VAULTED!")
		CollectionService:AddTag(apexSensor, "StuntGoalSensor")
	end
end

--------------------------------------------------------------------------------
-- 4. SMALL COCONUT ISLAND (~5 MIN OUT & LEFT)
--------------------------------------------------------------------------------
local function buildPalmTree(parent: Instance, baseLocal: Vector3, seed: number)
	local rng = Random.new(seed)
	local leanX = rng:NextNumber(-0.22, 0.22)
	local leanZ = rng:NextNumber(-0.22, 0.22)
	local curCF = CFrame.new(baseLocal)

	for seg = 1, 6 do
		local segH = 4.2
		curCF = curCF * CFrame.Angles(leanZ * 0.14, 0, leanX * 0.14) * CFrame.new(0, segH * 0.5, 0)
		makeLocalPart(parent, "PalmTrunk", Vector3.new(1.8 - seg * 0.14, segH + 0.4, 1.8 - seg * 0.14), curCF, Color3.fromRGB(138, 102, 68), Enum.Material.Wood)
		curCF = curCF * CFrame.new(0, segH * 0.5, 0)
	end

	for f = 1, 7 do
		local frondCF = curCF * CFrame.Angles(0, (f / 7) * math.pi * 2, 0) * CFrame.Angles(-0.38, 0, 0) * CFrame.new(0, 0, -5.5)
		makeLocalPart(parent, "PalmFrond", Vector3.new(2.4, 0.35, 11), frondCF, Color3.fromRGB(62, 138, 54), Enum.Material.Grass, false)
	end

	for c = 1, 4 do
		local ca = (c / 4) * math.pi * 2
		local coco = makeLocalPart(parent, "HangingCoconut", Vector3.new(1.3, 1.5, 1.3), curCF * CFrame.new(math.cos(ca) * 1.1, -0.4, math.sin(ca) * 1.1), Color3.fromRGB(88, 56, 32), Enum.Material.Wood, false)
		coco.Shape = Enum.PartType.Ball
	end
	for _ = 1, 2 do
		local fallen = makeLocalPart(parent, "FallenCoconut", Vector3.new(1.35, 1.35, 1.35), CFrame.new(baseLocal + Vector3.new(rng:NextNumber(-7, 7), 0.7, rng:NextNumber(-7, 7))), Color3.fromRGB(96, 62, 36), Enum.Material.Wood)
		fallen.Shape = Enum.PartType.Ball
	end
end

local function buildSmallIsland()
	local smallModel = Instance.new("Model")
	smallModel.Name = "SmallCoconutIsland"
	smallModel:SetAttribute("IslandType", "Small")
	CollectionService:AddTag(smallModel, "DistantIslandModel")
	smallModel.Parent = distantIslandsFolder

	local center = WaterfrontConfig.SMALL_ISLAND.LOCAL_POS
	local r = WaterfrontConfig.SMALL_ISLAND.RADIUS
	local sandBase = makeLocalPart(smallModel, "SandShoal", Vector3.new(22, r * 2.0, r * 2.0), CFrame.new(center + Vector3.new(0, -3, 0)) * CFrame.Angles(0, 0, math.rad(90)), Color3.fromRGB(236, 218, 172), Enum.Material.Sand)
	sandBase.Shape = Enum.PartType.Cylinder
	local sandCrown = makeLocalPart(smallModel, "SandCrown", Vector3.new(10, r * 1.15, r * 1.15), CFrame.new(center + Vector3.new(0, 6, 0)) * CFrame.Angles(0, 0, math.rad(90)), Color3.fromRGB(240, 224, 182), Enum.Material.Sand)
	sandCrown.Shape = Enum.PartType.Cylinder

	makeLocalPart(smallModel, "CayOutcrop", Vector3.new(38, 18, 32), CFrame.new(center + Vector3.new(-36, 10, -24)) * CFrame.Angles(0.12, 0.5, -0.08), Color3.fromRGB(104, 100, 95), Enum.Material.Slate)
	buildPalmTree(smallModel, center + Vector3.new(14, 10.5, 8), 501)
	buildPalmTree(smallModel, center + Vector3.new(-8, 10.5, 22), 502)
	buildPalmTree(smallModel, center + Vector3.new(26, 9.8, -18), 503)
end

--------------------------------------------------------------------------------
-- 5. ASYMMETRIC BIG CLIFF ISLAND, RUSH-BY WATERFALL DIVE CHUTES, STREAMS,
--    7-CHARACTER TRAIL, HIDDEN CHEST ALCOVE & 3-ROUTE SHEER CLIMB
--------------------------------------------------------------------------------
local function buildAlpinePine(parent: Instance, baseLocal: Vector3, scale: number, windLeanRad: number)
	local trunkCF = CFrame.new(baseLocal + Vector3.new(0, 7.5 * scale, 0)) * CFrame.Angles(0, 0, windLeanRad)
	makeLocalPart(parent, "PineTrunk", Vector3.new(2.3 * scale, 15 * scale, 2.3 * scale), trunkCF, Color3.fromRGB(88, 58, 38), Enum.Material.Wood)
	for tier = 1, 4 do
		local w = (14.5 - tier * 2.6) * scale
		local h = 7.2 * scale
		local boughOrigin = trunkCF * CFrame.new(0, (-3 + tier * 4.2) * scale, 0)
		local col = if tier % 2 == 0 then Color3.fromRGB(38, 84, 50) else Color3.fromRGB(46, 96, 58)
		makeLocalWedge(parent, "PineFoliageA", Vector3.new(w, h, w * 0.5), boughOrigin * CFrame.new(0, 0, -w * 0.25), col, Enum.Material.Grass)
		makeLocalWedge(parent, "PineFoliageB", Vector3.new(w, h, w * 0.5), boughOrigin * CFrame.new(0, 0, w * 0.25) * CFrame.Angles(0, math.pi, 0), col, Enum.Material.Grass)
	end
end

local function buildTrailStyleSegment(parent: Instance, p1: Vector3, p2: Vector3, width: number, style: "JaggedScramble" | "LateralShelf" | "ChasmPlatforms" | "ChimneySteps")
	local delta = p2 - p1
	local dist = delta.Magnitude
	local flatLook = Vector3.new(delta.X, 0, delta.Z)
	flatLook = if flatLook.Magnitude < 0.01 then Vector3.zAxis else flatLook.Unit

	if style == "LateralShelf" then
		local sub = math.max(2, math.floor(dist / 36))
		for i = 0, sub - 1 do
			local segStart = p1:Lerp(p2, i / sub)
			local segEnd = p1:Lerp(p2, (i + 1) / sub)
			local mid = (segStart + segEnd) * 0.5 - Vector3.new(0, 2.2, 0)
			local len = (segEnd - segStart).Magnitude + 4
			makeLocalPart(parent, "LateralCliffShelf", Vector3.new(width, 4.4, len), CFrame.lookAt(mid, segEnd - Vector3.new(0, 2.2, 0)), Color3.fromRGB(126, 120, 110), Enum.Material.Rock)
		end
	elseif style == "ChasmPlatforms" then
		local count = math.max(3, math.floor(dist / 26))
		for i = 0, count do
			local pt = p1:Lerp(p2, i / count)
			local slabLen = math.max(14, (dist / count) - 6.2)
			makeLocalPart(
				parent,
				"ChasmPlatformSlab",
				Vector3.new(width * 1.15, 5.2, slabLen),
				CFrame.lookAt(pt - Vector3.new(0, 2.6, 0), pt - Vector3.new(0, 2.6, 0) + flatLook) * CFrame.Angles(0, math.sin(i * 1.7) * 0.08, 0),
				Color3.fromRGB(112, 108, 102),
				Enum.Material.Slate
			)
		end
	elseif style == "ChimneySteps" then
		local steps = math.max(5, math.floor(dist / 10))
		for s = 0, steps do
			local pt = p1:Lerp(p2, s / steps)
			local cf = CFrame.lookAt(pt - Vector3.new(0, 2.2, 0), pt - Vector3.new(0, 2.2, 0) + flatLook)
			makeLocalPart(parent, "ChimneyStep", Vector3.new(width, 4.8, 11.5), cf, Color3.fromRGB(98, 94, 90), Enum.Material.Slate)
			if s % 3 == 0 then
				makeLocalPart(parent, "ChimneyFinL", Vector3.new(4.5, 22, 14), cf * CFrame.new(-(width * 0.5 + 2.2), 9, 0), Color3.fromRGB(80, 78, 74), Enum.Material.Slate)
				makeLocalPart(parent, "ChimneyFinR", Vector3.new(4.5, 20, 14), cf * CFrame.new(width * 0.5 + 2.2, 8, 0), Color3.fromRGB(84, 80, 76), Enum.Material.Slate)
			end
		end
	else
		local steps = math.max(4, math.floor(dist / 12.5))
		for s = 0, steps do
			local jitter = Vector3.new(math.sin(s * 2.4) * 3.4, 0, math.cos(s * 1.8) * 3.0)
			local pt = p1:Lerp(p2, s / steps) + jitter
			makeLocalPart(
				parent,
				"JaggedScrambleBlock",
				Vector3.new(width * 1.12, 5.8, 13.5),
				CFrame.lookAt(pt - Vector3.new(0, 2.7, 0), pt - Vector3.new(0, 2.7, 0) + flatLook) * CFrame.Angles(0, math.sin(s * 1.3) * 0.22, math.cos(s * 2.1) * 0.04),
				Color3.fromRGB(110, 106, 100),
				Enum.Material.Slate
			)
		end
	end
end

-- Builds an articulated vertical waterfall chute where rootCF.LookVector (-Z in rootCF space)
-- points strictly OUTWARD in the direction water cascades and the diver plunges.
local function buildDetailedDiveWaterfall(
	parent: Instance,
	lipLocal: Vector3,
	bottomY: number,
	width: number,
	outwardLocalDir: Vector3,
	diveConfig: { DiveName: string, PoolDepth: number }?
)
	local chuteModel = Instance.new("Model")
	chuteModel.Name = if diveConfig then "DiveWaterfall_" .. diveConfig.DiveName else "CascadeWaterfall"
	chuteModel.Parent = parent

	local totalDrop = lipLocal.Y - bottomY
	local flatOut = Vector3.new(outwardLocalDir.X, 0, outwardLocalDir.Z).Unit
	local rootCF = CFrame.lookAt(lipLocal, lipLocal + flatOut) -- -Z = outward dive direction; +Z = upstream into rock
	local rng = Random.new(math.floor(math.abs(lipLocal.X * 13 + lipLocal.Y * 7)))

	-- 1. Multi-Layered Rushing Water Curtain & Mid-Drop Spray Deflector Teeth
	local segments = math.max(4, math.floor(totalDrop / 36))
	local segDrop = totalDrop / segments
	for s = 1, segments do
		local midFrac = ((s - 1) / segments + s / segments) * 0.5
		local dropY = -midFrac * totalDrop
		local outDist = 1.4 + midFrac * 6.0 -- Cascades forward along -Z of rootCF

		local sheetCF = rootCF * CFrame.new(0, dropY, -outDist) * CFrame.Angles(math.rad(3.2), 0, 0)
		local outerSheet = makeLocalPart(chuteModel, "WaterCurtainOuter", Vector3.new(width, segDrop + 2.5, 4.2), sheetCF, Color3.fromRGB(184, 234, 252), Enum.Material.Glass, false)
		outerSheet.Transparency = 0.26

		local foamCore = makeLocalPart(chuteModel, "WaterFoamCore", Vector3.new(width * 0.66, segDrop + 2.0, 2.4), sheetCF * CFrame.new(0, 0, -0.9), Color3.fromRGB(242, 250, 255), Enum.Material.Neon, false)
		foamCore.Transparency = 0.50

		if diveConfig and (s == 2 or s == 4) then
			local sideSign = if s == 2 then -1 else 1
			local toothCF = rootCF * CFrame.new(sideSign * (width * 0.34), dropY, -(outDist - 0.6)) * CFrame.Angles(-0.22, sideSign * 0.3, -0.15)
			makeLocalPart(chuteModel, "SprayDeflectorTooth", Vector3.new(width * 0.42, 7.5, 8.5), toothCF, Color3.fromRGB(64, 62, 60), Enum.Material.Slate, false)

			local sprayAnchor = makeLocalPart(chuteModel, "MidCliffSpray", Vector3.new(4, 2, 4), toothCF * CFrame.new(0, 2.5, -3.5), Color3.new(1, 1, 1), Enum.Material.SmoothPlastic, false)
			sprayAnchor.Transparency = 1
			local ledgeSpray = Instance.new("ParticleEmitter")
			ledgeSpray.Rate = 34
			ledgeSpray.Lifetime = NumberRange.new(1.0, 1.8)
			ledgeSpray.Speed = NumberRange.new(10, 22)
			ledgeSpray.SpreadAngle = Vector2.new(55, 40)
			ledgeSpray.Size = NumberSequence.new({ NumberSequenceKeypoint.new(0, 3.5), NumberSequenceKeypoint.new(1, 14) })
			ledgeSpray.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.45), NumberSequenceKeypoint.new(1, 1) })
			ledgeSpray.Parent = sprayAnchor
		end
	end

	-- 2. Articulated "Rush-By" Cliff Wall Strata, Basalt Columns & Clinging Ferns
	if diveConfig then
		local strataCount = math.floor(totalDrop / 11)
		for i = 1, strataCount do
			local yOff = -i * 11 + rng:NextNumber(-1.5, 1.5)
			makeLocalPart(
				chuteModel,
				"WetGorgeBackwall",
				Vector3.new(width * 1.6, 12.5, 8),
				rootCF * CFrame.new(0, yOff, 3.5 - (i / strataCount) * 3.2),
				if i % 2 == 0 then Color3.fromRGB(54, 58, 60) else Color3.fromRGB(46, 50, 52),
				Enum.Material.Slate
			)

			for _, side in { -1, 1 } do
				local xPos = side * (width * 0.56 + rng:NextNumber(2.5, 9.5))
				local zJutOut = rng:NextNumber(1.5, 6.2)
				local ribH = rng:NextNumber(8.5, 14.5)
				local ribW = rng:NextNumber(10, 18)
				local ribCF = rootCF
					* CFrame.new(xPos, yOff, -zJutOut)
					* CFrame.Angles(rng:NextNumber(-0.12, 0.12), side * rng:NextNumber(0.08, 0.35), rng:NextNumber(-0.1, 0.1))

				makeLocalPart(
					chuteModel,
					"RushByCliffRib",
					Vector3.new(ribW, ribH, rng:NextNumber(9, 15)),
					ribCF,
					if (i + side) % 3 == 0 then Color3.fromRGB(88, 84, 78) else Color3.fromRGB(68, 66, 64),
					Enum.Material.Slate
				)

				if i % 3 == 0 then
					makeLocalPart(chuteModel, "StrataShelfLip", Vector3.new(ribW * 0.85, 2.4, 5.5), ribCF * CFrame.new(-side * 2.2, ribH * 0.42, -3.2), Color3.fromRGB(104, 98, 90), Enum.Material.Rock, false)
					makeLocalPart(chuteModel, "CliffFernTuft", Vector3.new(4.8, 2.2, 4.2), ribCF * CFrame.new(-side * 1.8, ribH * 0.52, -3.0), Color3.fromRGB(48, 112, 54), Enum.Material.Grass, false)
				end
			end
		end

		-- 3. Upper Crest Feed Stream, Split Lip Boulders & Cantilevered E-Key Dive Stone
		makeLocalPart(chuteModel, "UpperFeedStream", Vector3.new(width * 0.9, 1.2, 28), rootCF * CFrame.new(0, 0.2, 14), Color3.fromRGB(78, 178, 208), Enum.Material.Glass, false)
		makeLocalPart(chuteModel, "LipBoulderLeft", Vector3.new(8.5, 5.5, 8.5), rootCF * CFrame.new(-(width * 0.5 + 3.2), 1.8, 1.0) * CFrame.Angles(0, 0.3, 0), Color3.fromRGB(82, 80, 76), Enum.Material.Slate)
		makeLocalPart(chuteModel, "LipBoulderRight", Vector3.new(9.5, 6.2, 9.0), rootCF * CFrame.new(width * 0.5 + 3.6, 2.1, 1.2) * CFrame.Angles(0, -0.25, 0), Color3.fromRGB(78, 76, 72), Enum.Material.Slate)

		local diveStoneCF = rootCF * CFrame.new(0, 0.8, -1.8)
		local diveStone = makeLocalPart(chuteModel, "WaterfallDivePlatform", Vector3.new(7.4, 2.2, 10.5), diveStoneCF, Color3.fromRGB(112, 108, 100), Enum.Material.Slate)
		makeLocalPart(chuteModel, "WetMossEdge", Vector3.new(7.0, 0.35, 3.2), diveStoneCF * CFrame.new(0, 1.15, -3.4), Color3.fromRGB(62, 118, 58), Enum.Material.Grass)

		local forwardWorld = WaterfrontConfig.localCFrameToWorld(rootCF).LookVector
		local targetPoolLocal = (rootCF * CFrame.new(0, -totalDrop, -15.0)).Position
		local targetWorldWaterY = WaterfrontConfig.localToWorld(targetPoolLocal).Y

		diveStone:SetAttribute("DiveName", diveConfig.DiveName)
		diveStone:SetAttribute("ForwardDir", Vector3.new(forwardWorld.X, 0, forwardWorld.Z).Unit)
		diveStone:SetAttribute("TargetWaterY", targetWorldWaterY)
		diveStone:SetAttribute("PoolDepth", diveConfig.PoolDepth)
		CollectionService:AddTag(diveStone, "WaterfallDiveLedge")

		local divePrompt = Instance.new("ProximityPrompt")
		divePrompt.ActionText = "Jump & First-Person Dive"
		divePrompt.ObjectText = diveConfig.DiveName
		divePrompt.KeyboardKeyCode = Enum.KeyCode.E
		divePrompt.HoldDuration = 0
		divePrompt.MaxActivationDistance = 11
		divePrompt.Parent = diveStone
	end

	-- 4. Deep Carved Plunge Pool Basin & Boiling Mist Ring at Bottom
	local poolDepth = if diveConfig then diveConfig.PoolDepth else 3
	local poolRadius = width * 1.25 + 12
	local poolCenterCF = rootCF * CFrame.new(0, -totalDrop, -15.0)

	local waterVolume = makeLocalPart(
		chuteModel,
		"DeepPlungePoolWater",
		Vector3.new(poolRadius * 2, poolDepth, poolRadius * 2),
		poolCenterCF * CFrame.new(0, -poolDepth * 0.5, 0),
		Color3.fromRGB(54, 168, 202),
		Enum.Material.Glass,
		false
	)
	waterVolume.Transparency = 0.24

	local boilRing = makeLocalPart(chuteModel, "AeratedFoamBoil", Vector3.new(1.2, width * 1.45, width * 1.45), poolCenterCF * CFrame.new(0, -0.2, 4) * CFrame.Angles(0, 0, math.rad(90)), Color3.fromRGB(224, 248, 255), Enum.Material.Neon, false)
	boilRing.Shape = Enum.PartType.Cylinder
	boilRing.Transparency = 0.45

	if diveConfig and poolDepth >= 10 then
		makeLocalPart(chuteModel, "PlungeBasinFloor", Vector3.new(poolRadius * 2.2, 3, poolRadius * 2.2), poolCenterCF * CFrame.new(0, -poolDepth - 1.2, 0), Color3.fromRGB(48, 56, 58), Enum.Material.Slate)
		for side = -1, 1, 2 do
			makeLocalPart(chuteModel, "PlungeBasinWallX", Vector3.new(5, poolDepth + 2, poolRadius * 2.1), poolCenterCF * CFrame.new(side * poolRadius, -poolDepth * 0.5, 0), Color3.fromRGB(62, 66, 64), Enum.Material.Slate)
		end
		makeLocalPart(chuteModel, "PlungeBasinWallBack", Vector3.new(poolRadius * 2.1, poolDepth + 2, 5), poolCenterCF * CFrame.new(0, -poolDepth * 0.5, poolRadius), Color3.fromRGB(58, 62, 60), Enum.Material.Slate)

		local poolGlow = Instance.new("PointLight")
		poolGlow.Color = Color3.fromRGB(95, 220, 245)
		poolGlow.Range = 42
		poolGlow.Brightness = 1.6
		poolGlow.Parent = waterVolume
	end

	local mist = Instance.new("ParticleEmitter")
	mist.Rate = 52
	mist.Lifetime = NumberRange.new(2.2, 3.8)
	mist.Speed = NumberRange.new(8, 18)
	mist.SpreadAngle = Vector2.new(48, 36)
	mist.Size = NumberSequence.new({ NumberSequenceKeypoint.new(0, 8), NumberSequenceKeypoint.new(1, 28) })
	mist.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.42), NumberSequenceKeypoint.new(1, 1) })
	mist.Parent = boilRing
end

local function buildBigCliffIsland()
	local bigModel = Instance.new("Model")
	bigModel.Name = "BigCliffIsland"
	bigModel:SetAttribute("IslandType", "Big")
	CollectionService:AddTag(bigModel, "DistantIslandModel")
	bigModel.Parent = distantIslandsFolder

	local c = WaterfrontConfig.BIG_ISLAND.LOCAL_POS
	local rng = Random.new(8824)

	-- 1. Smuggler's Cove Shingle Beach (+Z), Asymmetric Sea Stacks & Driftwood Jetty
	makeLocalPart(bigModel, "SmugglersCoveBeach", Vector3.new(220, 12, 145), CFrame.new(c + Vector3.new(35, 1.2, 575)) * CFrame.Angles(-0.08, 0.08, 0), Color3.fromRGB(222, 206, 168), Enum.Material.Sand)
	makeLocalPart(bigModel, "CoveSeaStackWest", Vector3.new(68, 128, 74), CFrame.new(c + Vector3.new(-105, 56, 615)) * CFrame.Angles(0.08, 0.4, -0.06), Color3.fromRGB(78, 76, 72), Enum.Material.Slate)
	makeLocalPart(bigModel, "CoveSeaStackEast", Vector3.new(82, 152, 86), CFrame.new(c + Vector3.new(178, 68, 598)) * CFrame.Angles(-0.07, -0.35, 0.08), Color3.fromRGB(72, 70, 68), Enum.Material.Slate)
	makeLocalPart(bigModel, "DriftwoodJetty", Vector3.new(10, 1.1, 56), CFrame.new(c + Vector3.new(-18, 3.0, 645)), Color3.fromRGB(116, 86, 58), Enum.Material.WoodPlanks)

	-- 2. Asymmetric Crag Perimeter & Recessed Hanging Valley
	for tier = 1, 6 do
		local yBot = (tier - 1) * 60 - 14
		local tierH = 66
		local segCount = 16
		for seg = 1, segCount do
			local ang = (seg / segCount) * math.pi * 2 + tier * 0.17
			local asymMult = 1.0 + 0.18 * math.cos(ang * 2 - 0.6) - 0.14 * math.sin(ang * 3)
			local baseRad = (555 - tier * 50) * asymMult
			local inWestBowl = (tier >= 5) and (math.cos(ang) < -0.35 and math.abs(math.sin(ang)) < 0.78)
			if not inWestBowl then
				local bx = math.cos(ang) * baseRad
				local bz = math.sin(ang) * baseRad
				local w = (2 * math.pi * baseRad) / segCount + 52
				makeLocalPart(
					bigModel,
					"AsymCliffCrag",
					Vector3.new(w, tierH, 168),
					CFrame.new(c + Vector3.new(bx, yBot + tierH * 0.5, bz))
						* CFrame.Angles(rng:NextNumber(-0.08, 0.08), -ang + math.pi * 0.5, rng:NextNumber(-0.07, 0.07)),
					if (tier + seg) % 2 == 0 then Color3.fromRGB(92, 90, 86) else Color3.fromRGB(78, 76, 73),
					Enum.Material.Slate
				)
			end
		end
		if tier <= 3 then
			makeLocalPart(bigModel, "MassifCore_" .. tier, Vector3.new(680 - tier * 75, tierH, 680 - tier * 75), CFrame.new(c + Vector3.new(10, yBot + tierH * 0.5, -15)), Color3.fromRGB(84, 88, 78), Enum.Material.Rock)
		end
	end

	-- 3. Hanging Pine Terrace (Y = 236) Framed Cleanly Around the Carved 18-Stud Bridalveil Plunge Basin
	--    Plunge pool center sits at local (-165, -27) with radius ~44.5 -> cutout box X:[-210,-120], Z:[-72,+18]
	makeLocalPart(bigModel, "AlpineBenchSouth", Vector3.new(430, 10, 268), CFrame.new(c + Vector3.new(-115, 231, 152)), Color3.fromRGB(58, 104, 52), Enum.Material.Grass)
	makeLocalPart(bigModel, "AlpineBenchWestWing", Vector3.new(120, 10, 90), CFrame.new(c + Vector3.new(-270, 231, -27)), Color3.fromRGB(58, 104, 52), Enum.Material.Grass)
	makeLocalPart(bigModel, "AlpineBenchEastWing", Vector3.new(220, 10, 90), CFrame.new(c + Vector3.new(-10, 231, -27)), Color3.fromRGB(58, 104, 52), Enum.Material.Grass)

	-- Sheer Waterfall Headwall & Upland Bridalveil Crest Meadow (Y = 448)
	makeLocalPart(bigModel, "WaterfallHeadwall", Vector3.new(265, 232, 82), CFrame.new(c + Vector3.new(-155, 336, -86)), Color3.fromRGB(72, 70, 68), Enum.Material.Slate)
	makeLocalPart(bigModel, "BridalveilCrestPlateau", Vector3.new(118, 12, 86), CFrame.new(c + Vector3.new(-158, 442, -78)), Color3.fromRGB(64, 106, 58), Enum.Material.Grass)

	-- DIVE WATERFALL 1: High Bridalveil Plunge (Y = 448 -> 236, 212-stud drop into 18-stud-deep pool!)
	buildDetailedDiveWaterfall(
		bigModel,
		c + Vector3.new(-165, 448, -42),
		c.Y + 236,
		26,
		Vector3.new(0, 0, 1),
		{ DiveName = "Bridalveil Falls Crest (212 FT)", PoolDepth = 18 }
	)

	-- Secondary ambient cascade: East Ravine Mist Cascade (Y = 358 -> 236)
	buildDetailedDiveWaterfall(
		bigModel,
		c + Vector3.new(-68, 358, -32),
		c.Y + 236,
		14,
		Vector3.new(-0.15, 0, 0.988),
		nil
	)

	-- Stream 1 (West Meadow Brook): flows out of Bridalveil Plunge Pool & shoots off the Sea Cliff
	local brookPts = {
		Vector3.new(-165, 236.1, 18),
		Vector3.new(-142, 236.0, 62),
		Vector3.new(-118, 235.9, 118),
		Vector3.new(-182, 235.7, 186),
		Vector3.new(-308, 235.5, 220),
	}
	for i = 1, #brookPts - 1 do
		local a, b = c + brookPts[i], c + brookPts[i + 1]
		local sPart = makeLocalPart(bigModel, "WestMeadowBrook", Vector3.new(15, 1.0, (b - a).Magnitude + 4), CFrame.lookAt((a + b) * 0.5, b), Color3.fromRGB(74, 176, 208), Enum.Material.Glass, false)
		sPart.Transparency = 0.18
	end

	-- DIVE WATERFALL 2: West Sea-Cliff Spillway (Y = 236 -> Sea Level, 236-stud dive into deep ocean!)
	buildDetailedDiveWaterfall(
		bigModel,
		c + Vector3.new(-318, 236, 222),
		c.Y + 0,
		14,
		Vector3.new(-0.92, 0, 0.39),
		{ DiveName = "Sea-Cliff Spillway (236 FT)", PoolDepth = 16 }
	)

	-- Stepping stones across West Meadow Brook
	for st = -2, 2 do
		makeLocalPart(bigModel, "BrookSteppingStone", Vector3.new(5.2, 2.2, 4.6), CFrame.new(c + Vector3.new(-118 + st * 2.2, 236.2, 118 + st * 5.8)) * CFrame.Angles(0, st * 0.3, 0), Color3.fromRGB(128, 126, 120), Enum.Material.Rock)
	end

	-- Stream 2 (Hidden Pine Creek) & Fallen Mossy Pine Log Bridge
	local creekStart = c + Vector3.new(-72, 236.0, 2)
	local creekEnd = c + Vector3.new(-225, 235.8, 175)
	local creekPart = makeLocalPart(bigModel, "HiddenPineCreek", Vector3.new(11, 0.9, (creekEnd - creekStart).Magnitude), CFrame.lookAt((creekStart + creekEnd) * 0.5, creekEnd), Color3.fromRGB(68, 166, 196), Enum.Material.Glass, false)
	creekPart.Transparency = 0.20

	local logBridgeCF = CFrame.lookAt(c + Vector3.new(-172, 237.4, 108), c + Vector3.new(-198, 237.4, 116))
	makeLocalPart(bigModel, "FallenPineLogBridge", Vector3.new(3.6, 2.6, 28), logBridgeCF, Color3.fromRGB(94, 66, 42), Enum.Material.Wood)
	makeLocalPart(bigModel, "LogMossStrip", Vector3.new(2.8, 0.4, 27), logBridgeCF * CFrame.new(0, 1.35, 0), Color3.fromRGB(68, 122, 58), Enum.Material.Grass)

	-- Wind-sculpted Alpine Pine Groves
	for _ = 1, 34 do
		local px = rng:NextNumber(-305, 35)
		local pz = rng:NextNumber(25, 265)
		local nearTrail = math.abs(px + 95) < 24 and pz > 90
		local nearCreek = math.abs((px + 150) - (pz - 80) * -0.8) < 14
		if not nearTrail and not nearCreek then
			buildAlpinePine(bigModel, c + Vector3.new(px, 236, pz), rng:NextNumber(0.85, 1.45), rng:NextNumber(-0.08, 0.08))
		end
	end

	-- 4. Non-Spiral 7-Character Ascent Trail + Bridalveil Headwall Rim Scramble + Summit Catwalk
	local trailStages: { { From: Vector3, To: Vector3, Width: number, Style: "JaggedScramble" | "LateralShelf" | "ChasmPlatforms" | "ChimneySteps" } } = {
		{ From = c + Vector3.new(38, 6, 545),     To = c + Vector3.new(195, 58, 488),   Width = 17, Style = "JaggedScramble" },
		{ From = c + Vector3.new(195, 58, 488),   To = c + Vector3.new(368, 76, 315),   Width = 14, Style = "LateralShelf" },
		{ From = c + Vector3.new(368, 76, 315),   To = c + Vector3.new(275, 162, 165),  Width = 16, Style = "ChasmPlatforms" },
		{ From = c + Vector3.new(275, 162, 165),  To = c + Vector3.new(45, 198, 285),   Width = 17, Style = "LateralShelf" },
		{ From = c + Vector3.new(45, 198, 285),   To = c + Vector3.new(-95, 236, 132),  Width = 16, Style = "JaggedScramble" },
		{ From = c + Vector3.new(-132, 236, 102), To = c + Vector3.new(-62, 312, 82),   Width = 13, Style = "ChimneySteps" },
		{ From = c + Vector3.new(-62, 312, 82),   To = c + Vector3.new(32, 360, 128),   Width = 16, Style = "LateralShelf" },

		-- Bridalveil Headwall Rim Scramble (Lookout Y = 360 -> Bridalveil Dive Crest Y = 448)
		{ From = c + Vector3.new(-32, 356, 104),  To = c + Vector3.new(-96, 394, 48),   Width = 13, Style = "JaggedScramble" },
		{ From = c + Vector3.new(-96, 394, 48),   To = c + Vector3.new(-144, 428, -4),  Width = 12, Style = "LateralShelf" },
		{ From = c + Vector3.new(-144, 428, -4),  To = c + Vector3.new(-158, 448, -48), Width = 12, Style = "ChimneySteps" },

		-- Summit-to-Waterfall Descent Catwalk (True Pinnacle Y = 485 -> Bridalveil Dive Crest Y = 448)
		{ From = c + Vector3.new(-42, 485, -24),  To = c + Vector3.new(-126, 448, -58), Width = 11, Style = "JaggedScramble" },
	}
	for _, seg in trailStages do
		buildTrailStyleSegment(bigModel, seg.From, seg.To, seg.Width, seg.Style)
	end
	makeLocalPart(bigModel, "SeaShelfOverhangBrow", Vector3.new(36, 18, 195), CFrame.lookAt(c + Vector3.new(272, 78, 405), c + Vector3.new(368, 92, 315)), Color3.fromRGB(78, 75, 70), Enum.Material.Slate)

	-- 5. Hidden Side Trail & Sheltered Mountaineer's Chest Alcove
	local chestPos = c + WaterfrontConfig.BIG_ISLAND.CHEST_LOCAL_OFFSET
	buildTrailStyleSegment(bigModel, c + Vector3.new(-142, 236, 106), c + Vector3.new(-168, 236, 108), 8, "JaggedScramble")
	buildTrailStyleSegment(bigModel, c + Vector3.new(-202, 236, 116), chestPos + Vector3.new(10, 0, 8), 8, "JaggedScramble")

	buildAlpinePine(bigModel, chestPos + Vector3.new(16, 0, 15), 1.45, 0.05)
	buildAlpinePine(bigModel, chestPos + Vector3.new(-14, 0, 16), 1.35, -0.06)
	buildAlpinePine(bigModel, chestPos + Vector3.new(4, 0, 22), 1.25, 0.03)
	makeLocalPart(bigModel, "AlcoveBackWall", Vector3.new(26, 20, 10), CFrame.new(chestPos + Vector3.new(0, 9, -8)), Color3.fromRGB(78, 76, 72), Enum.Material.Slate)
	makeLocalPart(bigModel, "AlcoveHoodSlab", Vector3.new(28, 6, 18), CFrame.new(chestPos + Vector3.new(0, 18, -2)) * CFrame.Angles(0.18, 0, 0), Color3.fromRGB(86, 84, 78), Enum.Material.Slate)

	local chestBase = makeLocalPart(bigModel, "OldClimbingChest", Vector3.new(4.8, 2.8, 3.1), CFrame.new(chestPos + Vector3.new(0, 1.4, 0)) * CFrame.Angles(0, 0.42, 0), Color3.fromRGB(94, 60, 32), Enum.Material.WoodPlanks)
	makeLocalPart(bigModel, "ChestIronStrapA", Vector3.new(5.0, 2.95, 0.35), chestBase.CFrame * CFrame.new(0, 0, -0.9), Color3.fromRGB(54, 52, 50), Enum.Material.CorrodedMetal)
	makeLocalPart(bigModel, "ChestIronStrapB", Vector3.new(5.0, 2.95, 0.35), chestBase.CFrame * CFrame.new(0, 0, 0.9), Color3.fromRGB(54, 52, 50), Enum.Material.CorrodedMetal)
	local propRope = makeLocalPart(bigModel, "ChestRopeProp", Vector3.new(0.8, 2.4, 2.4), chestBase.CFrame * CFrame.new(3.2, -0.9, 0.4) * CFrame.Angles(0, 0, math.rad(90)), Color3.fromRGB(214, 164, 72), Enum.Material.Fabric, false)
	propRope.Shape = Enum.PartType.Cylinder
	CollectionService:AddTag(chestBase, "ClimbingGearChest")

	local chestPrompt = Instance.new("ProximityPrompt")
	chestPrompt.ActionText = "Equip Mountaineer Harness, Chalk & 5 Pitons"
	chestPrompt.ObjectText = "Hidden Climber's Chest"
	chestPrompt.KeyboardKeyCode = Enum.KeyCode.E
	chestPrompt.HoldDuration = 0.35
	chestPrompt.MaxActivationDistance = 10
	chestPrompt.Parent = chestBase

	-- 6. Timber-Framed Main Lookout Deck (Y = 360)
	makeLocalPart(bigModel, "LookoutDeck", Vector3.new(196, 8, 188), CFrame.new(c + Vector3.new(32, 356, 88)), Color3.fromRGB(118, 114, 106), Enum.Material.Slate)
	for rx = -76, 76, 30 do
		makeLocalPart(bigModel, "LookoutTimberPost", Vector3.new(1.5, 4.8, 1.5), CFrame.new(c + Vector3.new(32 + rx, 362.4, 178)), Color3.fromRGB(110, 76, 46), Enum.Material.Wood)
	end
	makeLocalPart(bigModel, "LookoutTopRail", Vector3.new(158, 0.75, 1.0), CFrame.new(c + Vector3.new(32, 364.4, 178)), Color3.fromRGB(122, 86, 54), Enum.Material.Wood)
	makeLocalPart(bigModel, "LookoutStoneBench", Vector3.new(16, 2.2, 4.2), CFrame.new(c + Vector3.new(32, 361.1, 162)), Color3.fromRGB(98, 96, 92), Enum.Material.Slate)

	-- 7. Upper 1/4 Sheer Monolith (Y = 360 -> 485) & 3-Route Climbing Wall
	local wallCenterX = c.X + 18
	local baseFaceZ = c.Z + 52.0

	makeLocalPart(bigModel, "UpperQuarterSheerFace", Vector3.new(142, 130, 138), CFrame.new(wallCenterX, c.Y + 422, c.Z - 18) * CFrame.Angles(math.rad(5), 0, 0), Color3.fromRGB(74, 72, 70), Enum.Material.Slate)
	makeLocalPart(bigModel, "LeftDihedralWingWall", Vector3.new(18, 126, 28), CFrame.new(wallCenterX - 28, c.Y + 422, baseFaceZ + 4) * CFrame.Angles(math.rad(5), math.rad(28), 0), Color3.fromRGB(82, 80, 76), Enum.Material.Slate)
	makeLocalPart(bigModel, "CenterOverhangRoofCrux", Vector3.new(26, 22, 12), CFrame.new(wallCenterX, c.Y + 435, baseFaceZ - 1.5) * CFrame.Angles(math.rad(-14), 0, 0), Color3.fromRGB(66, 64, 62), Enum.Material.Slate)

	local wetStreak = makeLocalPart(bigModel, "RightWaterfallMistStreak", Vector3.new(18, 118, 1.2), CFrame.new(wallCenterX + 19, c.Y + 421, baseFaceZ - 4.8) * CFrame.Angles(math.rad(5), 0, 0), Color3.fromRGB(48, 72, 82), Enum.Material.Glass, false)
	wetStreak.Transparency = 0.55

	makeLocalPart(bigModel, "TruePinnacleSummit", Vector3.new(124, 6, 124), CFrame.new(wallCenterX, c.Y + 485, c.Z - 22), Color3.fromRGB(114, 110, 104), Enum.Material.Rock)
	for cairn = 1, 5 do
		local s = 7.5 - cairn * 1.1
		makeLocalPart(bigModel, "SummitCairnStone", Vector3.new(s, 2.2, s * 0.9), CFrame.new(wallCenterX, c.Y + 488 + cairn * 2.0, c.Z - 18) * CFrame.Angles(0, cairn * 0.7, 0), Color3.fromRGB(134, 130, 122), Enum.Material.Slate)
	end

	local startAnchor = makeLocalPart(bigModel, "ClimbStartAnchor", Vector3.new(2.4, 2.4, 1.5), CFrame.new(wallCenterX, c.Y + 363.5, baseFaceZ + 1.2), Color3.fromRGB(186, 140, 66), Enum.Material.Metal)
	CollectionService:AddTag(startAnchor, "ClimbStartTrigger")

	local startPrompt = Instance.new("ProximityPrompt")
	startPrompt.ActionText = "Tie In & Begin First-Person Sheer Climb"
	startPrompt.ObjectText = "Upper Monolith Belay Ring"
	startPrompt.KeyboardKeyCode = Enum.KeyCode.E
	startPrompt.HoldDuration = 0.25
	startPrompt.MaxActivationDistance = 10
	startPrompt.Parent = startAnchor

	local holdsFolder = Instance.new("Folder")
	holdsFolder.Name = "ClimbingHolds"
	holdsFolder.Parent = bigModel

	local function spawnHold(hType: string, localX: number, localY: number, localZ: number, row: number, isTop: boolean)
		local spec = WaterfrontConfig.CLIMBING.HOLD_TYPES[hType]
		local part = makeLocalPart(holdsFolder, "Hold_" .. hType .. "_" .. row, spec.Size, CFrame.new(localX, localY, localZ), spec.Color, Enum.Material.Rock)
		part:SetAttribute("HoldType", hType)
		part:SetAttribute("Row", row)
		part:SetAttribute("IsTopOut", isTop)
		CollectionService:AddTag(part, "RockClimbHold")
	end

	local tiers = 22
	for row = 1, tiers do
		local alpha = row / tiers
		local y = c.Y + 365.5 + alpha * 118.5
		local slopeZ = baseFaceZ - alpha * 10.8

		if row == tiers then
			for _, xOff in { -16, 0, 16 } do
				spawnHold("Ledge", wallCenterX + xOff, y, slopeZ, row, true)
			end
		else
			local lx = wallCenterX - 17 + rng:NextNumber(-2.4, 2.4)
			local leftHand = if row % 6 == 0 then "Ledge" elseif row % 3 == 0 then "PitonCrack" else "Crimp"
			spawnHold(leftHand, lx, y, slopeZ + 0.6, row, false)
			spawnHold("FootChip", lx + rng:NextNumber(-2.0, 2.2), y - 2.6, slopeZ + 0.7, row, false)

			local cx = wallCenterX + rng:NextNumber(-3.0, 3.0)
			local inRoof = (y >= c.Y + 423 and y <= c.Y + 447)
			local roofBulgeZ = if inRoof then 3.8 else 0.0
			local centerHand = if row == 10 or row == 17 then "Ledge" elseif row % 4 == 0 then "PitonCrack" elseif inRoof then "Jug" else "Sloper"
			spawnHold(centerHand, cx, y, slopeZ + roofBulgeZ, row, false)
			if not inRoof or row % 2 == 0 then
				spawnHold("FootChip", cx + rng:NextNumber(-2.5, 2.5), y - 2.8, slopeZ + roofBulgeZ * 0.6, row, false)
			end

			local rx = wallCenterX + 18 + rng:NextNumber(-2.6, 2.6)
			local rightHand = if row == 12 then "Ledge"
				elseif row % 4 == 1 then "LooseRock"
				elseif row % 3 == 0 then "WetSloper"
				elseif row % 5 == 0 then "PitonCrack"
				else "Jug"
			spawnHold(rightHand, rx, y, slopeZ + 0.4, row, false)
			spawnHold("FootChip", rx + rng:NextNumber(-2.2, 2.2), y - 2.5, slopeZ + 0.5, row, false)

			if row == 7 or row == 14 then
				spawnHold("Jug", wallCenterX - 8.5, y - 1.0, slopeZ + 0.5, row, false)
				spawnHold("FootChip", wallCenterX - 8.0, y - 4.2, slopeZ + 0.5, row, false)
				spawnHold("Jug", wallCenterX + 9.0, y - 0.8, slopeZ + 0.5, row, false)
				spawnHold("FootChip", wallCenterX + 8.5, y - 4.0, slopeZ + 0.5, row, false)
			end
		end
	end
end

buildMarinaDock()
buildSeaCaveHeadland(nearShoreFolder, -1)
buildSeaCaveHeadland(nearShoreFolder, 1)
buildStuntCourse()
buildSmallIsland()
buildBigCliffIsland()
