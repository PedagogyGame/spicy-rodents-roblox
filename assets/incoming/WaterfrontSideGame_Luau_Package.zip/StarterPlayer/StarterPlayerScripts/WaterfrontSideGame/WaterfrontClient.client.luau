--!strict
-- WaterfrontClient.client.luau
-- Watertight 3D Wedge-Triangle Ocean Surface (batched BulkMoveTo), Harbor/Beach Masking,
-- 6-Point Planing & Wave-Slam Watercraft Hydrodynamics, Planetary Curvature Island Rise,
-- Vague Summit Silhouettes, First-Person Rock Climbing, and First-Person Waterfall Diving.
-- Leaves Sky, Sun, Clouds, and Map/Minimap completely untouched.

local CollectionService = game:GetService("CollectionService")
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
local TweenService = game:GetService("TweenService")
local UserInputService = game:GetService("UserInputService")
local Workspace = game:GetService("Workspace")

local localPlayer = Players.LocalPlayer
local camera = Workspace.CurrentCamera

local sideGameFolder = ReplicatedStorage:WaitForChild("WaterfrontSideGame")
local WaterfrontConfig = require(sideGameFolder:WaitForChild("WaterfrontConfig"))
local OceanWaveSolver = require(sideGameFolder:WaitForChild("OceanWaveSolver"))
local FirstPersonClimbClient = require(sideGameFolder:WaitForChild("FirstPersonClimbClient"))
local WaterfallDiveClient = require(sideGameFolder:WaitForChild("WaterfallDiveClient"))

local remotes = sideGameFolder:WaitForChild("Remotes")
local vehicleEvent = remotes:WaitForChild("VehicleControlEvent") :: RemoteEvent
local stuntFeedbackEvent = remotes:WaitForChild("StuntFeedbackEvent") :: RemoteEvent

--------------------------------------------------------------------------------
-- 1. TACTILE STUNT BANNER HUD (STRICTLY ZERO MAP / ZERO MINIMAP / ZERO COMPASS)
--------------------------------------------------------------------------------
local screenGui = Instance.new("ScreenGui")
screenGui.Name = "WaterfrontSideGameHUD"
screenGui.ResetOnSpawn = false
screenGui.Parent = localPlayer:WaitForChild("PlayerGui")

local bannerLabel = Instance.new("TextLabel")
bannerLabel.Size = UDim2.new(0, 520, 0, 42)
bannerLabel.Position = UDim2.new(0.5, -260, 0.14, 0)
bannerLabel.BackgroundTransparency = 1
bannerLabel.Font = Enum.Font.GothamBold
bannerLabel.TextSize = 22
bannerLabel.TextColor3 = Color3.fromRGB(255, 224, 112)
bannerLabel.TextStrokeTransparency = 0.35
bannerLabel.Text = ""
bannerLabel.Parent = screenGui

local function showBanner(msg: string)
	bannerLabel.Text = msg
	bannerLabel.TextTransparency = 0
	task.delay(2.8, function()
		if bannerLabel.Text == msg then
			TweenService:Create(bannerLabel, TweenInfo.new(0.6), { TextTransparency = 1 }):Play()
		end
	end)
end

stuntFeedbackEvent.OnClientEvent:Connect(function(label: string, streak: number)
	if streak > 1 then
		showBanner(string.format("%s  (x%d STUNT STREAK)", label, streak))
	else
		showBanner(label)
	end
end)

FirstPersonClimbClient.init(screenGui, showBanner)
WaterfallDiveClient.init(showBanner)

--------------------------------------------------------------------------------
-- 2. WATERTIGHT 3D TRIANGULATED OCEAN MESH + OUTER HORIZON SKIRT
--    Uses exact right-triangle WedgePart pairs updated via single BulkMoveTo.
--------------------------------------------------------------------------------
local oceanVisualFolder = Instance.new("Folder")
oceanVisualFolder.Name = "ClientDynamicOcean"
oceanVisualFolder.Parent = Workspace

type TriCell = {
	GX: number,
	GZ: number,
	CellSize: number,
	Lod: number,
	W1: WedgePart,
	W2: WedgePart,
	W3: WedgePart,
	W4: WedgePart,
}

type SkirtSlab = {
	GX: number,
	GZ: number,
	TileSize: number,
	Part: Part,
}

local triCells: { TriCell } = {}
local skirtSlabs: { SkirtSlab } = {}
local bulkParts: { BasePart } = {}
local bulkCFrames: { CFrame } = {}

local COASTAL_TEAL = Color3.fromRGB(28, 136, 164)
local DEEP_OCEAN_BLUE = Color3.fromRGB(16, 82, 122)
local ABYSS_NAVY = Color3.fromRGB(11, 52, 86)
local SURF_FOAM = Color3.fromRGB(236, 248, 255)
local CULL_CFRAME = CFrame.new(0, -1200, 0)
local MESH_THICKNESS = 0.55

local function makeOceanWedge(): WedgePart
	local w = Instance.new("WedgePart")
	w.Name = "WaveTriWedge"
	w.Size = Vector3.new(MESH_THICKNESS, 1, 1)
	w.Anchored = true
	w.CanCollide = false
	w.CastShadow = false
	w.Material = Enum.Material.Glass
	w.Transparency = 0.12
	w.Color = COASTAL_TEAL
	w.Parent = oceanVisualFolder
	return w
end

local function buildOceanMeshPools()
	-- Ring 1: High-detail watertight triangle mesh (12x12 cells @ 26 studs = 312x312 around camera)
	for gx = -6, 5 do
		for gz = -6, 5 do
			table.insert(triCells, {
				GX = gx,
				GZ = gz,
				CellSize = 26,
				Lod = 0,
				W1 = makeOceanWedge(),
				W2 = makeOceanWedge(),
				W3 = makeOceanWedge(),
				W4 = makeOceanWedge(),
			})
		end
	end

	-- Ring 2: Mid-range rolling swell mesh (10x10 ring @ 78 studs = 780x780, excluding inner 4x4 core)
	for gx = -5, 4 do
		for gz = -5, 4 do
			if gx < -2 or gx >= 2 or gz < -2 or gz >= 2 then
				table.insert(triCells, {
					GX = gx,
					GZ = gz,
					CellSize = 78,
					Lod = 1,
					W1 = makeOceanWedge(),
					W2 = makeOceanWedge(),
					W3 = makeOceanWedge(),
					W4 = makeOceanWedge(),
				})
			end
		end
	end

	-- Ring 3: Wide open-ocean horizon skirt (8x8 hollow ring @ 340 studs = 2,720x2,720 visual sea expanse)
	for gx = -4, 3 do
		for gz = -4, 3 do
			if gx < -1 or gx >= 1 or gz < -1 or gz >= 1 then
				local p = Instance.new("Part")
				p.Name = "HorizonWaveSkirt"
				p.Size = Vector3.new(348, 2.2, 348)
				p.Anchored = true
				p.CanCollide = false
				p.CastShadow = false
				p.Material = Enum.Material.Glass
				p.Transparency = 0.10
				p.Color = COASTAL_TEAL
				p.Parent = oceanVisualFolder
				table.insert(skirtSlabs, { GX = gx, GZ = gz, TileSize = 340, Part = p })
			end
		end
	end

	for _, cell in triCells do
		table.insert(bulkParts, cell.W1)
		table.insert(bulkParts, cell.W2)
		table.insert(bulkParts, cell.W3)
		table.insert(bulkParts, cell.W4)
	end
	for _, slab in skirtSlabs do
		table.insert(bulkParts, slab.Part)
	end
	bulkCFrames = table.create(#bulkParts, CULL_CFRAME)
end
buildOceanMeshPools()

local function computeTriangleWedges(a: Vector3, b: Vector3, c: Vector3, w1: WedgePart, w2: WedgePart): (CFrame, CFrame)
	local ab, ac, bc = b - a, c - a, c - b
	local abd, acd, bcd = ab:Dot(ab), ac:Dot(ac), bc:Dot(bc)

	if abd > acd and abd > bcd then
		c, a = a, c
	elseif acd > bcd and acd > abd then
		a, b = b, a
	end

	ab, ac, bc = b - a, c - a, c - b
	local cross = ac:Cross(ab)
	if cross.Magnitude < 0.0001 then
		return CULL_CFRAME, CULL_CFRAME
	end

	local right = cross.Unit
	local up = bc:Cross(right).Unit
	local back = bc.Unit

	local height = math.abs(ab:Dot(up))
	w1.Size = Vector3.new(MESH_THICKNESS, height, math.abs(ab:Dot(back)))
	w2.Size = Vector3.new(MESH_THICKNESS, height, math.abs(ac:Dot(back)))

	local cf1 = CFrame.fromMatrix((a + b) * 0.5, right, up, back)
	local cf2 = CFrame.fromMatrix((a + c) * 0.5, -right, up, -back)
	return cf1, cf2
end

local vertexCache: { [string]: OceanWaveSolver.WaveSample } = {}
local function sampleCached(wx: number, wz: number, now: number, lod: number): OceanWaveSolver.WaveSample
	local key = string.format("%d_%d_%d", math.round(wx), math.round(wz), lod)
	local hit = vertexCache[key]
	if hit then
		return hit
	end
	local s = OceanWaveSolver.sample(wx, wz, now, lod)
	vertexCache[key] = s
	return s
end

--------------------------------------------------------------------------------
-- 3. PLANETARY CURVATURE OCCLUSION & SUMMIT HORIZON SILHOUETTES
--------------------------------------------------------------------------------
local silhouetteFolder = Instance.new("Folder")
silhouetteFolder.Name = "SummitHorizonSilhouettes"
silhouetteFolder.Parent = Workspace

local mainlandSilhouette = Instance.new("Model")
mainlandSilhouette.Parent = silhouetteFolder
for i = 1, 7 do
	local b = Instance.new("Part")
	b.Anchored = true
	b.CanCollide = false
	b.CastShadow = false
	b.Material = Enum.Material.SmoothPlastic
	b.Color = Color3.fromRGB(142, 168, 186)
	b.Transparency = 1
	b.Size = Vector3.new(38 + (i % 3) * 18, 26 + (i % 4) * 22, 18)
	b:SetAttribute("OffsetIdx", i - 4)
	b.Parent = mainlandSilhouette
end

local smallIslandSilhouette = Instance.new("Part")
smallIslandSilhouette.Anchored = true
smallIslandSilhouette.CanCollide = false
smallIslandSilhouette.CastShadow = false
smallIslandSilhouette.Material = Enum.Material.SmoothPlastic
smallIslandSilhouette.Shape = Enum.PartType.Cylinder
smallIslandSilhouette.Color = Color3.fromRGB(148, 174, 188)
smallIslandSilhouette.Size = Vector3.new(12, 46, 46)
smallIslandSilhouette.Transparency = 1
smallIslandSilhouette.Parent = silhouetteFolder

local islandBasePivots: { [Model]: CFrame } = {}

local function applyModelOcclusionAndCurvature(model: Model, hidden: boolean, transparencyAlpha: number, curvatureDropY: number)
	if not islandBasePivots[model] then
		islandBasePivots[model] = model:GetPivot()
	end
	local basePivot = islandBasePivots[model]
	model:PivotTo(basePivot + Vector3.new(0, if hidden then -800 else curvatureDropY, 0))

	local modAlpha = if hidden then 1 else transparencyAlpha
	for _, d in model:GetDescendants() do
		if d:IsA("BasePart") then
			d.LocalTransparencyModifier = modAlpha
		elseif d:IsA("ParticleEmitter") then
			d.Enabled = not hidden and modAlpha < 0.72
		end
	end
end

local lastHorizonUpdate = 0
local function updateOceanSpatialMapping(focusWorldPos: Vector3)
	local localPos = WaterfrontConfig.worldToLocal(focusWorldPos)
	local distFromMainland = Vector2.new(localPos.X, localPos.Z).Magnitude
	local zones = WaterfrontConfig.ZONES

	local worldRoot = Workspace:FindFirstChild("WaterfrontSideGameWorld")
	local nearShore = worldRoot and worldRoot:FindFirstChild("NearShoreStructures")
	if nearShore then
		local shoreAlpha = math.clamp((distFromMainland - zones.MAINLAND_FADE_START) / (zones.MAINLAND_VANISH_DIST - zones.MAINLAND_FADE_START), 0, 1)
		for _, d in nearShore:GetDescendants() do
			if d:IsA("BasePart") then
				d.LocalTransparencyModifier = shoreAlpha
			end
		end
	end

	for _, inst in CollectionService:GetTagged("DistantIslandModel") do
		if inst:IsA("Model") then
			local iType = (inst:GetAttribute("IslandType") :: string?) == "Small" and "Small" or "Big"
			local visible, alpha, curveDrop = WaterfrontConfig.computeIslandVisibility(localPos, iType :: "Small" | "Big")
			applyModelOcclusionAndCurvature(inst, not visible, alpha, curveDrop)
		end
	end

	local bigCenterWorld = WaterfrontConfig.localToWorld(WaterfrontConfig.BIG_ISLAND.LOCAL_POS)
	local seaY = WaterfrontConfig.getOriginCFrame().Position.Y
	local altitudeAboveSea = focusWorldPos.Y - seaY
	local onBigSummit = (Vector2.new(focusWorldPos.X - bigCenterWorld.X, focusWorldPos.Z - bigCenterWorld.Z).Magnitude < 980)
		and (altitudeAboveSea >= 325)

	if onBigSummit then
		local originWorld = WaterfrontConfig.getOriginCFrame().Position
		local toMainlandDir = Vector3.new(originWorld.X - focusWorldPos.X, 0, originWorld.Z - focusWorldPos.Z).Unit
		local rightDir = toMainlandDir:Cross(Vector3.yAxis).Unit
		local silBase = Vector3.new(focusWorldPos.X, seaY + 12, focusWorldPos.Z) + toMainlandDir * 2900

		for _, p in mainlandSilhouette:GetChildren() do
			if p:IsA("BasePart") then
				local idx = (p:GetAttribute("OffsetIdx") :: number) or 0
				p.CFrame = CFrame.lookAt(silBase + rightDir * (idx * 58) + Vector3.new(0, p.Size.Y * 0.45, 0), focusWorldPos)
				p.Transparency = 0.74
			end
		end

		local smallWorld = WaterfrontConfig.localToWorld(WaterfrontConfig.SMALL_ISLAND.LOCAL_POS)
		local toSmallDir = Vector3.new(smallWorld.X - focusWorldPos.X, 0, smallWorld.Z - focusWorldPos.Z).Unit
		smallIslandSilhouette.CFrame = CFrame.new(Vector3.new(focusWorldPos.X, seaY + 3, focusWorldPos.Z) + toSmallDir * 2850)
			* CFrame.Angles(0, 0, math.rad(90))
		smallIslandSilhouette.Transparency = 0.82
	else
		for _, p in mainlandSilhouette:GetChildren() do
			if p:IsA("BasePart") then
				p.Transparency = 1
			end
		end
		smallIslandSilhouette.Transparency = 1
	end
end

--------------------------------------------------------------------------------
-- 4. 6-POINT PLANING, CHINE CARVING & WAVE-SLAM WATERCRAFT HYDRODYNAMICS
--------------------------------------------------------------------------------
local lastHopTime = 0
local wasAirborne = false
local lastCutoffWarn = 0

UserInputService.InputBegan:Connect(function(input: InputObject, gameProcessed: boolean)
	if gameProcessed then
		return
	end
	if input.KeyCode == Enum.KeyCode.E then
		local char = localPlayer.Character
		local hum = char and char:FindFirstChildOfClass("Humanoid")
		if hum and hum.SeatPart and hum.SeatPart.Parent and CollectionService:HasTag(hum.SeatPart.Parent, "SimWatercraft") then
			vehicleEvent:FireServer("Dismount")
		end
	end
end)

local function stepWatercraftPhysics(dt: number, now: number)
	if FirstPersonClimbClient.isClimbing() or WaterfallDiveClient.isDiving() then
		return
	end

	local char = localPlayer.Character
	local hum = char and char:FindFirstChildOfClass("Humanoid")
	local hrp = char and char:FindFirstChild("HumanoidRootPart") :: BasePart?
	if not hum or not hrp then
		return
	end

	local seat = hum.SeatPart
	if seat and seat.Parent and CollectionService:HasTag(seat.Parent, "SimWatercraft") then
		local craft = seat.Parent :: Model
		local hull = craft.PrimaryPart
		if not hull then
			return
		end
		local vType = (craft:GetAttribute("VehicleType") :: string?) or "JetSki"
		local profile = WaterfrontConfig.VEHICLES[vType]
		local vf = hull:FindFirstChild("WaveAndThrustForce") :: VectorForce?
		local ao = hull:FindFirstChild("HullStabilizer") :: AlignOrientation?
		if not vf or not ao then
			return
		end

		local throttle = (if UserInputService:IsKeyDown(Enum.KeyCode.W) then 1 else 0) - (if UserInputService:IsKeyDown(Enum.KeyCode.S) then 1 else 0)
		local steer = (if UserInputService:IsKeyDown(Enum.KeyCode.D) then -1 else 0) + (if UserInputService:IsKeyDown(Enum.KeyCode.A) then 1 else 0)
		local boosting = UserInputService:IsKeyDown(Enum.KeyCode.LeftShift)
		local airPitchInput = (if UserInputService:IsKeyDown(Enum.KeyCode.Up) then -1 else 0) + (if UserInputService:IsKeyDown(Enum.KeyCode.Down) then 1 else 0)

		local hx = profile.HullSize.X * 0.46
		local hz = profile.HullSize.Z * 0.46
		local pBow     = hull.CFrame:PointToWorldSpace(Vector3.new(0, 0, -hz))
		local pStern   = hull.CFrame:PointToWorldSpace(Vector3.new(0, 0, hz))
		local pFwdPort = hull.CFrame:PointToWorldSpace(Vector3.new(-hx, 0, -hz * 0.45))
		local pFwdStar = hull.CFrame:PointToWorldSpace(Vector3.new(hx, 0, -hz * 0.45))
		local pAftPort = hull.CFrame:PointToWorldSpace(Vector3.new(-hx, 0, hz * 0.55))
		local pAftStar = hull.CFrame:PointToWorldSpace(Vector3.new(hx, 0, hz * 0.55))

		local sCenter  = OceanWaveSolver.sample(hull.Position.X, hull.Position.Z, now, 0)
		local sBow     = OceanWaveSolver.sample(pBow.X, pBow.Z, now, 0)
		local sStern   = OceanWaveSolver.sample(pStern.X, pStern.Z, now, 0)
		local sFwdPort = OceanWaveSolver.sample(pFwdPort.X, pFwdPort.Z, now, 0)
		local sFwdStar = OceanWaveSolver.sample(pFwdStar.X, pFwdStar.Z, now, 0)
		local sAftPort = OceanWaveSolver.sample(pAftPort.X, pAftPort.Z, now, 0)
		local sAftStar = OceanWaveSolver.sample(pAftStar.X, pAftStar.Z, now, 0)

		if sCenter.zoneName == "OuterCutoff" and now - lastCutoffWarn > 6.0 then
			lastCutoffWarn = now
			showBanner("ROGUE OUTER OCEAN CURRENT - TURNING HULL INWARD")
		end

		local rayParams = RaycastParams.new()
		rayParams.FilterDescendantsInstances = { craft, char :: Instance, oceanVisualFolder }
		rayParams.FilterType = Enum.RaycastFilterType.Exclude
		local rampHit = Workspace:Raycast(hull.Position + Vector3.new(0, 2.2, 0), Vector3.new(0, -5.6, 0), rayParams)
		local onRamp = rampHit ~= nil and CollectionService:HasTag(rampHit.Instance, "StuntLaunchRamp")

		local avgWaveY = (sBow.height + sStern.height + sFwdPort.height + sFwdStar.height + sAftPort.height + sAftStar.height) / 6
		local submergence = avgWaveY - hull.Position.Y
		local inWater = (submergence > -1.35) and not onRamp

		local mass = hull.AssemblyMass
		local vel = hull.AssemblyLinearVelocity
		local relWaterVel = vel - sCenter.orbitalVelocity
		local totalForce = Vector3.zero

		if onRamp and rampHit then
			wasAirborne = false
			local rampNormal = rampHit.Normal
			local forwardAlongRamp = (hull.CFrame.LookVector - hull.CFrame.LookVector:Dot(rampNormal) * rampNormal).Unit
			local maxSpd = profile.MaxSpeed + (if boosting then profile.BoostBonus else 0) + 14
			if vel.Magnitude < maxSpd and throttle > 0 then
				totalForce += forwardAlongRamp * (mass * profile.Acceleration * 1.4)
			end
			local right = forwardAlongRamp:Cross(rampNormal).Unit
			ao.Responsiveness = 28
			ao.CFrame = CFrame.fromMatrix(Vector3.zero, right, rampNormal, -forwardAlongRamp)
		elseif inWater then
			local flatForward = Vector3.new(hull.CFrame.LookVector.X, 0, hull.CFrame.LookVector.Z).Unit
			local flatRight = Vector3.new(hull.CFrame.RightVector.X, 0, hull.CFrame.RightVector.Z).Unit
			local forwardSpeed = relWaterVel:Dot(flatForward)
			local maxSpd = profile.MaxSpeed + (if boosting then profile.BoostBonus else 0)

			if wasAirborne then
				wasAirborne = false
				local noseDotWave = hull.CFrame.LookVector:Dot(sCenter.normal)
				if noseDotWave < -0.38 and vel.Y < -18 then
					hull.AssemblyLinearVelocity = Vector3.new(vel.X * 0.62, vel.Y * 0.35, vel.Z * 0.62)
				elseif math.abs(noseDotWave) < 0.25 and throttle > 0 then
					hull:ApplyImpulse(flatForward * (mass * 12))
				end
			end

			local planeRatio = math.clamp((forwardSpeed - profile.PlaningSpeed) / math.max(10, maxSpd - profile.PlaningSpeed), 0, 1)
			local planingLiftAccel = planeRatio * profile.PlaningLift

			local buoyAccel = Workspace.Gravity
				+ math.clamp(submergence, -1.2, 4.8) * profile.BuoyancyStiffness
				+ planingLiftAccel
				- relWaterVel.Y * profile.BuoyancyDamping

			local surfBuck = 0
			if (sCenter.chop > 0.65 or sCenter.clapotis > 0.3) and vel.Magnitude > 16 then
				surfBuck = math.sin(now * 21.0 + hull.Position.X * 0.15) * (sCenter.chop + sCenter.clapotis) * profile.WaveRoughnessSensitivity * 15
			end
			totalForce += Vector3.new(0, mass * (buoyAccel + surfBuck), 0)

			if throttle ~= 0 then
				if (throttle > 0 and forwardSpeed < maxSpd) or (throttle < 0 and forwardSpeed > -maxSpd * 0.38) then
					totalForce += flatForward * (mass * profile.Acceleration * throttle)
				end
			end

			local sideSpeed = relWaterVel:Dot(flatRight)
			totalForce -= flatRight * (sideSpeed * mass * profile.ChineGrip)

			local hullDragCoeff = (0.34 - planeRatio * 0.14) + (if sCenter.zoneName == "BreakingSurf" then 0.28 else 0)
			totalForce -= Vector3.new(relWaterVel.X, 0, relWaterVel.Z) * (mass * hullDragCoeff)
			totalForce += sCenter.currentPush * mass

			if UserInputService:IsKeyDown(Enum.KeyCode.Space) and profile.BunnyHopImpulse > 0 and now - lastHopTime > 1.1 then
				lastHopTime = now
				hull:ApplyImpulse(Vector3.new(0, mass * profile.BunnyHopImpulse, 0))
			end

			local yawStep = steer * profile.TurnSpeed * dt * math.clamp(0.35 + math.abs(forwardSpeed) / 34, 0.35, 1.28)
			local nextLook = (CFrame.Angles(0, yawStep, 0) * flatForward)

			local portAvgY = (sFwdPort.height + sAftPort.height) * 0.5
			local starAvgY = (sFwdStar.height + sAftStar.height) * 0.5
			local waveForwardVec = Vector3.new(pBow.X - pStern.X, sBow.height - sStern.height, pBow.Z - pStern.Z).Unit
			local waveRightVec = Vector3.new(pFwdStar.X - pFwdPort.X, starAvgY - portAvgY, pFwdStar.Z - pFwdPort.Z).Unit
			local hullUp = waveRightVec:Cross(waveForwardVec).Unit
			if hullUp.Y < 0 then
				hullUp = -hullUp
			end

			local bankAngle = -steer * math.clamp(forwardSpeed / maxSpd, 0, 1) * 0.38
			local planingBowTrim = planeRatio * math.rad(4.8)
			local alignedRight = nextLook:Cross(hullUp).Unit
			local alignedLook = hullUp:Cross(alignedRight).Unit
			ao.Responsiveness = 17
			ao.CFrame = CFrame.fromMatrix(Vector3.zero, alignedRight, hullUp, -alignedLook)
				* CFrame.Angles(planingBowTrim, 0, bankAngle)
		else
			if vel.Y > 6 or submergence < -2.4 then
				wasAirborne = true
			end
			ao.Responsiveness = 9.5
			local pitchDelta = (airPitchInput * 1.2 - throttle * 0.35) * profile.AirPitchTorque * dt
			local rollDelta = -steer * profile.AirRollTorque * dt
			ao.CFrame = ao.CFrame * CFrame.Angles(pitchDelta, steer * 0.48 * dt, rollDelta)
		end

		vf.Force = totalForce

		local sternAtt = hull:FindFirstChild("SternWakeAttachment")
		local wake = sternAtt and sternAtt:FindFirstChild("WakeSpray") :: ParticleEmitter?
		if wake then
			wake.Rate = if (inWater or onRamp) and vel.Magnitude > 13
				then math.clamp(vel.Magnitude * (1.15 + sCenter.breakerFoam * 0.7), 16, 125)
				else 0
		end
	elseif not hum.PlatformStand then
		local sample = OceanWaveSolver.sample(hrp.Position.X, hrp.Position.Z, now, 1)
		if not sample.masked and hrp.Position.Y < sample.height - 1.1 then
			local lift = math.clamp((sample.height - 0.75 - hrp.Position.Y) * 29, 0, 60)
			local drift = (sample.orbitalVelocity * 0.25 + sample.currentPush * 0.35) * dt
			hrp.AssemblyLinearVelocity = Vector3.new(
				hrp.AssemblyLinearVelocity.X * 0.95 + drift.X,
				math.max(hrp.AssemblyLinearVelocity.Y * 0.82 + lift * dt * 14, -6),
				hrp.AssemblyLinearVelocity.Z * 0.95 + drift.Z
			)
		end
	end
end

--------------------------------------------------------------------------------
-- MAIN CLIENT RENDER & PHYSICS LOOPS
--------------------------------------------------------------------------------
local function resolveWaterColor(s: OceanWaveSolver.WaveSample): Color3
	local base = if s.zoneName == "OuterCutoff" or s.zoneName == "AbyssalOcean"
		then ABYSS_NAVY
		elseif s.zoneName == "DeepOcean" then DEEP_OCEAN_BLUE
		else COASTAL_TEAL
	return base:Lerp(SURF_FOAM, s.breakerFoam * 0.78)
end

RunService.RenderStepped:Connect(function(dt: number)
	local now = Workspace:GetServerTimeNow()
	local camPos = camera.CFrame.Position
	table.clear(vertexCache)

	local idx = 1

	-- 1. Skin Ring 1 & Ring 2 Watertight 3D Triangle Ocean Meshes
	for _, cell in triCells do
		local sz = cell.CellSize
		local baseX = math.floor(camPos.X / sz) * sz + cell.GX * sz
		local baseZ = math.floor(camPos.Z / sz) * sz + cell.GZ * sz

		local s00 = sampleCached(baseX, baseZ, now, cell.Lod)
		local s10 = sampleCached(baseX + sz, baseZ, now, cell.Lod)
		local s01 = sampleCached(baseX, baseZ + sz, now, cell.Lod)
		local s11 = sampleCached(baseX + sz, baseZ + sz, now, cell.Lod)

		if s00.masked and s10.masked and s01.masked and s11.masked then
			bulkCFrames[idx] = CULL_CFRAME
			bulkCFrames[idx + 1] = CULL_CFRAME
			bulkCFrames[idx + 2] = CULL_CFRAME
			bulkCFrames[idx + 3] = CULL_CFRAME
		else
			local p00 = Vector3.new(baseX, s00.height, baseZ) + Vector3.new(s00.displacement.X, 0, s00.displacement.Z) * 0.35
			local p10 = Vector3.new(baseX + sz, s10.height, baseZ) + Vector3.new(s10.displacement.X, 0, s10.displacement.Z) * 0.35
			local p01 = Vector3.new(baseX, s01.height, baseZ + sz) + Vector3.new(s01.displacement.X, 0, s01.displacement.Z) * 0.35
			local p11 = Vector3.new(baseX + sz, s11.height, baseZ + sz) + Vector3.new(s11.displacement.X, 0, s11.displacement.Z) * 0.35

			local cf1, cf2 = computeTriangleWedges(p00, p10, p11, cell.W1, cell.W2)
			local cf3, cf4 = computeTriangleWedges(p00, p11, p01, cell.W3, cell.W4)

			bulkCFrames[idx] = cf1
			bulkCFrames[idx + 1] = cf2
			bulkCFrames[idx + 2] = cf3
			bulkCFrames[idx + 3] = cf4

			local colA = resolveWaterColor(s00)
			local colB = resolveWaterColor(s11)
			cell.W1.Color = colA
			cell.W2.Color = colA
			cell.W3.Color = colB
			cell.W4.Color = colB
		end
		idx += 4
	end

	-- 2. Skin Ring 3 Wide Ocean Horizon Skirt
	for _, slab in skirtSlabs do
		local sz = slab.TileSize
		local snapX = math.floor(camPos.X / sz) * sz + (slab.GX + 0.5) * sz
		local snapZ = math.floor(camPos.Z / sz) * sz + (slab.GZ + 0.5) * sz
		local s = sampleCached(snapX, snapZ, now, 2)

		if s.masked then
			bulkCFrames[idx] = CULL_CFRAME
		else
			local right = Vector3.zAxis:Cross(s.normal)
			right = if right.Magnitude < 0.001 then Vector3.xAxis else right.Unit
			local look = right:Cross(s.normal).Unit
			bulkCFrames[idx] = CFrame.fromMatrix(Vector3.new(snapX, s.height - 1.1, snapZ), right, s.normal, -look)
			slab.Part.Color = resolveWaterColor(s)
		end
		idx += 1
	end

	Workspace:BulkMoveTo(bulkParts, bulkCFrames, Enum.BulkMoveMode.FireCFrameChanged)

	-- 3. Update Planetary Curvature Occlusion & Summit Silhouettes at 5 Hz
	if now - lastHorizonUpdate > 0.20 then
		lastHorizonUpdate = now
		updateOceanSpatialMapping(camPos)
	end

	-- 4. Step First-Person Rock Climbing Controller
	FirstPersonClimbClient.step(dt, now)
end)

RunService.Heartbeat:Connect(function(dt: number)
	stepWatercraftPhysics(dt, Workspace:GetServerTimeNow())
end)
