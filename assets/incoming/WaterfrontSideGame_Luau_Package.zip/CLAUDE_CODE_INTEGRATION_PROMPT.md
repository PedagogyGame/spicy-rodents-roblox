# WaterfrontSideGame — Claude Code Integration Prompt & Architecture Guide

Copy and paste the prompt below into **Claude Code** after extracting this package into your repository (or point Claude Code directly at this folder):

---

## Copy-Paste Prompt for Claude Code

Integrate the 7-script `WaterfrontSideGame` Luau ocean simulator, stunt course, distant islands, first-person rock-climbing, and first-person waterfall cliff-diving package into this Roblox/Rojo repository. All 7 Luau files in this archive are already pre-merged across every pass and strictly typed (`--!strict`). Follow the integration rules below strictly:

### 1. Spatial Anchor & Breakwater Masking (`Workspace.WaterfrontOrigin`)
1. Inspect the existing map/waterfront generation scripts in this repo to find the exact world coordinates and width of the outer coastal stone breakwater enclosing the marina basin.
2. Create or spawn an anchored, non-collidable, invisible (`Transparency = 1`) `Part` named `WaterfrontOrigin` parented directly to `Workspace` before `WaterfrontSideGame` initializes:
   - Position `WaterfrontOrigin` on the outer ocean-facing lip of the stone breakwater right at sea-surface elevation (`Y = seaLevel`).
   - Orient `WaterfrontOrigin.CFrame.LookVector` straight out into the open ocean (`-Z` in local `WaterfrontOrigin` space = seaward; `+Z` = inland across the harbor/beach; `-X` = left along the coast; `+X` = right along the coast).
   - Update `WaterfrontConfig.DEFAULT_ORIGIN_CFRAME` to match this `CFrame` as a fallback.
3. Check the marina breakwater's half-width in the existing map code against `WaterfrontConfig.BREAKWATER_HALF_WIDTH` (`430` studs by default) and adjust that single constant if needed so:
   - Dynamic ocean wave triangles butt cleanly against the outer breakwater wall without clipping into the calm inner boat marina or sandy beach.
   - The flanking Utah sandstone cliffs, arches, hoodoos, and vaulted sea caves start just outside the existing left-flank coastal bluff and right-flank beach building.
4. If the existing map uses a large static flat ocean `Part` outside the breakwater, keep the calm water inside the enclosed marina basin intact, but hide or resize the outer open-sea flat plane so it does not intersect or z-fight with deep Gerstner wave troughs in `ClientDynamicOcean`.

### 2. Exact 7-File Rojo / Runtime Placement
Map the 7 included Luau scripts into `default.project.json` (see `rojo-snippet.project.json` for reference) so they compile into these exact Roblox services:

- `ReplicatedStorage/WaterfrontSideGame/WaterfrontConfig.luau` *(ModuleScript)*
- `ReplicatedStorage/WaterfrontSideGame/OceanWaveSolver.luau` *(ModuleScript)*
- `ReplicatedStorage/WaterfrontSideGame/FirstPersonClimbClient.luau` *(ModuleScript)*
- `ReplicatedStorage/WaterfrontSideGame/WaterfallDiveClient.luau` *(ModuleScript)*
- `ServerScriptService/WaterfrontSideGame/WaterfrontWorldBuilder.server.luau` *(Script)*
- `ServerScriptService/WaterfrontSideGame/WatercraftAndClimbServer.server.luau` *(Script)*
- `StarterPlayer/StarterPlayerScripts/WaterfrontSideGame/WaterfrontClient.client.luau` *(LocalScript)*

### 3. Strict Guardrails & Host-Game Coexistence
- **Sky, Sun & Clouds (Claude Executive Control):** Do NOT modify `Lighting`, `Sky`, `Atmosphere`, or `Clouds` inside `WaterfrontSideGame`. Keep your executive sky/cloud/lighting setup—just ensure the sun or primary directional sky cue remains visible so offshore players can navigate naturally.
- **Strict Zero-Map Rule:** Do NOT add any map, minimap, submap, waypoint marker, or compass UI anywhere.
- **Input & Camera Coexistence:** Preserve all existing town HUD elements and keybinds (`WASD`, `Shift`, `Space`, `F`, `E`, `V`, `K`, `M`). Ensure the existing client camera controller (such as `V` first-person toggle) and `E` vehicle entry script do not override `CameraMode`/`CameraType` or double-fire when:
  1. The player is seated in a `SimWatercraft`-tagged `VehicleSeat`,
  2. `FirstPersonClimbClient.isClimbing()` is `true`, or
  3. `WaterfallDiveClient.isDiving()` is `true`.
- **Fall-Damage / Anti-Teleport Compatibility:** If the repo has custom fall-damage, ragdoll, or anti-teleport checks, whitelist players seated in `SimWatercraft`, welded to `ClimbBelayRig`, or executing a `WaterfallDiveEvent` plunge.

### 4. Final Verification
Verify Rojo path mappings in `default.project.json`, confirm clean strict Luau syntax across all 7 files, and report the exact `WaterfrontOrigin` coordinates anchored onto the stone breakwater.

---

## Controls Summary (Zero Host-Game Keybind Collisions)

| Mode | Input | Action |
| :--- | :--- | :--- |
| **Marina / World** | `E` | Spawn watercraft at slip / Mount or dismount craft / Open hidden climbing chest / Tie into cliff climb / Jump & First-Person Waterfall Dive |
| **Watercraft** | `W` / `S`, `A` / `D` | Throttle & Chine-Carve Steering |
| **Watercraft** | `LeftShift` | Offshore Turbo Boost |
| **Watercraft** | `Space` | Wave-Crest Bunny Hop (Jet Ski & WaveRunner) |
| **Watercraft (Air)** | `Up` / `Down`, `A` / `D` | Mid-Air Stunt Pitch & Roll Trim |
| **1st-Person Climb** | `Left Mouse Click` | Grab Handhold (`Jug`, `Ledge`, `Crimp`, `Sloper`, `WetSloper`, `LooseRock`, `PitonCrack`) |
| **1st-Person Climb** | `Right Mouse` or `Q` | Step Boot onto Foothold (`FootChip` or any lower hold) to relieve arm tension |
| **1st-Person Climb** | `C` | Chalk Hands (boosts friction on `WetSloper` & `Sloper` holds) |
| **1st-Person Climb** | `R` | Drive Iron Piton into `PitonCrack` & clip live segmented belay rope |
| **1st-Person Climb** | `Backspace` | Safe Rappel Exit to last belay anchor |
| **1st-Person Dive** | `Mouse` + `A` / `D` | Glance across rushing rock ribs & carve along the waterfall curtain |
