--!strict
-- FirstPersonClimbClient.luau
-- Tactical First-Person Rock Climbing Controller: Hand vs. Footing Placement,
-- Body-Tension Span Math, Chalk Friction Buff, Loose-Flake Fracture & Mountain Wind Gusts.

local CollectionService = game:GetService("CollectionService")
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local UserInputService = game:GetService("UserInputService")
local Workspace = game:GetService("Workspace")

local localPlayer = Players.LocalPlayer
local mouse = localPlayer:GetMouse()
local camera = Workspace.CurrentCamera

local sideGameFolder = ReplicatedStorage:WaitForChild("WaterfrontSideGame")
local WaterfrontConfig = require(sideGameFolder:WaitForChild("WaterfrontConfig"))
local remotes = sideGameFolder:WaitForChild("Remotes")
local climbingEvent = remotes:WaitForChild("ClimbingEvent") :: RemoteEvent

local FirstPersonClimbClient = {}

local activeClimbing = false
local gripStamina = 100
local pitonsLeft = 5
local handPos = Vector3.zero
local footPos = Vector3.zero
local currentHandHold: BasePart? = nil
local currentFootHold: BasePart? = nil
local looseHoldTimer = 0
local chalkTimeRemaining = 0
local chalkCooldownRemaining = 0
local gustActive = false
local savedCameraMode = localPlayer.CameraMode

local showBannerFn: (string) -> () = function() end
local climbPanel: Frame
local gripBarFill: Frame
local stanceBadge: TextLabel
local climbHint: TextLabel
local hoverHighlight: Highlight
local handMarker: Part
local footMarker: Part

function FirstPersonClimbClient.isClimbing(): boolean
	return activeClimbing
end

local function makeLimbMarker(name: string, color: Color3): Part
	local p = Instance.new("Part")
	p.Name = name
	p.Shape = Enum.PartType.Ball
	p.Size = Vector3.new(0.65, 0.65, 0.65)
	p.Anchored = true
	p.CanCollide = false
	p.Material = Enum.Material.Neon
	p.Color = color
	p.Transparency = 1
	p.Parent = Workspace
	return p
end

local function computeStanceState(): (string, number)
	local span = handPos.Y - footPos.Y
	local lateralSkew = math.abs(handPos.X - footPos.X)
	local cfg = WaterfrontConfig.CLIMBING

	if span > cfg.MAX_BALANCED_SPAN then
		return "OVERSTRETCHED - STEP FEET UP (Q / Right-Click)", 2.75
	elseif span < cfg.MIN_BODY_SPAN then
		return "HIGH-STEP COILED - REACH HAND UP (Left-Click)", 1.45
	elseif lateralSkew > 6.5 then
		return "BARN-DOOR TENSION - CENTER YOUR FOOTING", 1.85
	else
		return "BALANCED 3-POINT STANCE (Legs Bearing Weight)", 0.45
	end
end

local function updateHUD()
	gripBarFill.Size = UDim2.new(math.clamp(gripStamina / 100, 0, 1), 0, 1, 0)
	gripBarFill.BackgroundColor3 = if gripStamina > 48
		then Color3.fromRGB(92, 214, 128)
		elseif gripStamina > 24 then Color3.fromRGB(242, 186, 62)
		else Color3.fromRGB(235, 72, 62)

	local stanceText, _ = computeStanceState()
	local chalkTag = if chalkTimeRemaining > 0 then " | [CHALKED]" elseif chalkCooldownRemaining <= 0 then " | [C: Chalk Ready]" else ""
	local gustTag = if gustActive then " | GALE GUST!" else ""
	stanceBadge.Text = stanceText .. chalkTag .. gustTag
	climbHint.Text = string.format("M1: Grab Hand  |  M2/Q: Step Foot  |  R: Piton (%d)  |  C: Chalk  |  Backspace: Exit", pitonsLeft)
end

local function stopClientClimb()
	activeClimbing = false
	currentHandHold = nil
	currentFootHold = nil
	hoverHighlight.Adornee = nil
	handMarker.Transparency = 1
	footMarker.Transparency = 1
	climbPanel.Visible = false
	localPlayer.CameraMode = savedCameraMode
end

function FirstPersonClimbClient.init(screenGui: ScreenGui, bannerCallback: (string) -> ())
	showBannerFn = bannerCallback

	climbPanel = Instance.new("Frame")
	climbPanel.Size = UDim2.new(0, 460, 0, 92)
	climbPanel.Position = UDim2.new(0.5, -230, 0.78, 0)
	climbPanel.BackgroundColor3 = Color3.fromRGB(18, 20, 24)
	climbPanel.BackgroundTransparency = 0.26
	climbPanel.Visible = false
	climbPanel.Parent = screenGui
	Instance.new("UICorner", climbPanel).CornerRadius = UDim.new(0, 8)

	local gripBarBg = Instance.new("Frame")
	gripBarBg.Size = UDim2.new(0.90, 0, 0, 13)
	gripBarBg.Position = UDim2.new(0.05, 0, 0.14, 0)
	gripBarBg.BackgroundColor3 = Color3.fromRGB(46, 48, 54)
	gripBarBg.Parent = climbPanel
	Instance.new("UICorner", gripBarBg).CornerRadius = UDim.new(0, 6)

	gripBarFill = Instance.new("Frame")
	gripBarFill.Size = UDim2.new(1, 0, 1, 0)
	gripBarFill.BackgroundColor3 = Color3.fromRGB(92, 214, 128)
	gripBarFill.Parent = gripBarBg
	Instance.new("UICorner", gripBarFill).CornerRadius = UDim.new(0, 6)

	stanceBadge = Instance.new("TextLabel")
	stanceBadge.Size = UDim2.new(0.92, 0, 0, 24)
	stanceBadge.Position = UDim2.new(0.04, 0, 0.36, 0)
	stanceBadge.BackgroundTransparency = 1
	stanceBadge.Font = Enum.Font.GothamBold
	stanceBadge.TextSize = 13
	stanceBadge.TextColor3 = Color3.fromRGB(162, 228, 250)
	stanceBadge.Parent = climbPanel

	climbHint = Instance.new("TextLabel")
	climbHint.Size = UDim2.new(0.94, 0, 0, 26)
	climbHint.Position = UDim2.new(0.03, 0, 0.65, 0)
	climbHint.BackgroundTransparency = 1
	climbHint.Font = Enum.Font.GothamMedium
	climbHint.TextSize = 12
	climbHint.TextColor3 = Color3.fromRGB(228, 232, 238)
	climbHint.Parent = climbPanel

	hoverHighlight = Instance.new("Highlight")
	hoverHighlight.FillTransparency = 0.5
	hoverHighlight.OutlineTransparency = 0.05
	hoverHighlight.Parent = screenGui

	handMarker = makeLimbMarker("ClimbHandMarker", Color3.fromRGB(110, 245, 155))
	footMarker = makeLimbMarker("ClimbFootMarker", Color3.fromRGB(95, 205, 255))

	climbingEvent.OnClientEvent:Connect(function(ev: string, arg1: any, arg2: any, arg3: any)
		if ev == "BeginClimb" then
			savedCameraMode = localPlayer.CameraMode
			localPlayer.CameraMode = Enum.CameraMode.LockFirstPerson
			activeClimbing = true
			gripStamina = 100
			handPos = arg1 :: Vector3
			footPos = arg2 :: Vector3
			pitonsLeft = (arg3 :: number?) or WaterfrontConfig.CLIMBING.STARTING_PITONS
			currentHandHold = nil
			currentFootHold = nil
			looseHoldTimer = 0
			chalkTimeRemaining = 0
			handMarker.CFrame = CFrame.new(handPos)
			footMarker.CFrame = CFrame.new(footPos)
			handMarker.Transparency = 0.25
			footMarker.Transparency = 0.25
			climbPanel.Visible = true
			updateHUD()
			showBannerFn("SHEER MONOLITH - BALANCE HAND REACH & BOOT FOOTING")
		elseif ev == "PitonUpdated" then
			pitonsLeft = (arg2 :: number?) or pitonsLeft
			updateHUD()
			showBannerFn("IRON PITON DRIVEN & BELAY ROPE CLIPPED!")
		elseif ev == "SummitReached" or ev == "ClimbExited" then
			stopClientClimb()
		end
	end)

	UserInputService.InputBegan:Connect(function(input: InputObject, gp: boolean)
		if not activeClimbing or gp then
			return
		end
		local hrp = localPlayer.Character and localPlayer.Character:FindFirstChild("HumanoidRootPart") :: BasePart?
		if not hrp then
			return
		end
		local cfg = WaterfrontConfig.CLIMBING

		-- HAND PLACEMENT (Left Mouse Click)
		if input.UserInputType == Enum.UserInputType.MouseButton1 then
			local target = mouse.Target
			if target and CollectionService:HasTag(target, "RockClimbHold") and not target:GetAttribute("Broken") then
				if target:GetAttribute("HoldType") == "FootChip" then
					showBannerFn("MICRO FOOT-CHIP - USE RIGHT-CLICK OR Q TO PLACE BOOT!")
					return
				end
				if (target.Position - hrp.Position).Magnitude > cfg.MAX_HAND_REACH then
					showBannerFn("HANDHOLD OUT OF REACH - STEP YOUR BOOTS UP FIRST")
					return
				end
				if target.Position.Y - footPos.Y > cfg.HARD_BODY_SPAN then
					showBannerFn("BODY FULLY EXTENDED - PLACE HIGHER FOOTING (Q / M2) FIRST!")
					return
				end

				currentHandHold = target
				handPos = target.Position
				handMarker.CFrame = CFrame.new(handPos)
				looseHoldTimer = 0
				local moveCost = if gustActive then 7.5 else 3.8
				gripStamina = math.max(0, gripStamina - moveCost)
				climbingEvent:FireServer("PlaceHand", target)
			end

		-- FOOTING PLACEMENT (Right Mouse Click or Q)
		elseif input.UserInputType == Enum.UserInputType.MouseButton2 or input.KeyCode == Enum.KeyCode.Q then
			local target = mouse.Target
			if target and CollectionService:HasTag(target, "RockClimbHold") and not target:GetAttribute("Broken") then
				if (target.Position - hrp.Position).Magnitude > cfg.MAX_FOOT_REACH then
					showBannerFn("FOOTHOLD TOO FAR FROM HIPS")
					return
				end
				if target.Position.Y > handPos.Y - 1.0 then
					showBannerFn("CANNOT PLACE BOOTS ABOVE YOUR HANDS!")
					return
				end

				currentFootHold = target
				footPos = target.Position
				footMarker.CFrame = CFrame.new(footPos)
				gripStamina = math.max(0, gripStamina - 1.5)
				climbingEvent:FireServer("PlaceFoot", target)
			end

		-- CHALK HANDS (C)
		elseif input.KeyCode == Enum.KeyCode.C then
			if chalkCooldownRemaining <= 0 then
				chalkTimeRemaining = cfg.CHALK_DURATION
				chalkCooldownRemaining = cfg.CHALK_COOLDOWN
				gripStamina = math.min(100, gripStamina + 10)
				showBannerFn("HANDS CHALKED - WET & SLOPER FRICTION BOOSTED!")
			else
				showBannerFn(string.format("CHALK RECHARGING (%.0fs)", chalkCooldownRemaining))
			end

		-- HAMMER PITON & CLIP BELAY ROPE (R)
		elseif input.KeyCode == Enum.KeyCode.R then
			local crackHold = if currentHandHold and currentHandHold:GetAttribute("HoldType") == "PitonCrack"
				then currentHandHold
				elseif mouse.Target and CollectionService:HasTag(mouse.Target, "RockClimbHold") and mouse.Target:GetAttribute("HoldType") == "PitonCrack" and (mouse.Target.Position - hrp.Position).Magnitude <= 7.5
				then mouse.Target
				else nil
			if crackHold and pitonsLeft > 0 then
				climbingEvent:FireServer("PlacePiton", crackHold)
			else
				showBannerFn("REACH A VERTICAL DARK ROCK SEAM TO DRIVE A PITON")
			end

		-- SAFE RAPPEL EXIT (Backspace)
		elseif input.KeyCode == Enum.KeyCode.Backspace then
			climbingEvent:FireServer("ExitClimb")
		end
	end)
end

function FirstPersonClimbClient.step(dt: number, now: number)
	if not activeClimbing then
		return
	end
	local hrp = localPlayer.Character and localPlayer.Character:FindFirstChild("HumanoidRootPart") :: BasePart?
	if not hrp then
		return
	end

	local cfg = WaterfrontConfig.CLIMBING
	chalkTimeRemaining = math.max(0, chalkTimeRemaining - dt)
	chalkCooldownRemaining = math.max(0, chalkCooldownRemaining - dt)

	local seaY = WaterfrontConfig.getOriginCFrame().Position.Y
	local phase = now % cfg.GUST_PERIOD
	local wasGust = gustActive
	gustActive = (hrp.Position.Y - seaY > 408) and (phase < cfg.GUST_DURATION)
	if gustActive and not wasGust then
		showBannerFn("HIGH-ALTITUDE CROSSWIND GUST - HOLD YOUR STANCE!")
	end
	if gustActive then
		camera.CFrame = camera.CFrame * CFrame.Angles(math.sin(now * 24) * 0.0025, math.cos(now * 19) * 0.003, 0)
	end

	local aimed = mouse.Target
	if aimed and CollectionService:HasTag(aimed, "RockClimbHold") and not aimed:GetAttribute("Broken") and (aimed.Position - hrp.Position).Magnitude <= cfg.MAX_HAND_REACH then
		hoverHighlight.Adornee = aimed
		local hType = (aimed:GetAttribute("HoldType") :: string?) or "Jug"
		hoverHighlight.FillColor = if hType == "FootChip"
			then Color3.fromRGB(80, 210, 255)
			elseif hType == "PitonCrack" then Color3.fromRGB(255, 208, 72)
			elseif hType == "LooseRock" or hType == "WetSloper" then Color3.fromRGB(245, 108, 62)
			else Color3.fromRGB(115, 240, 160)
	else
		hoverHighlight.Adornee = nil
	end

	local _, stanceMult = computeStanceState()
	local footRelief = if currentFootHold and currentFootHold:GetAttribute("HoldType") == "Ledge" then 0.55 else 1.0
	local gustMult = if gustActive then 1.45 else 1.0

	if currentHandHold then
		local hType = (currentHandHold:GetAttribute("HoldType") :: string?) or "Jug"
		local spec = cfg.HOLD_TYPES[hType]
		if spec then
			local chalkMult = if chalkTimeRemaining > 0 then 0.62 else 1.0
			local wetMult = if spec.WetPenalty and chalkTimeRemaining <= 0 then spec.WetPenalty else 1.0
			local netDelta = spec.RecoverRate - (cfg.BASE_GRIP_DRAIN * spec.DrainMult * stanceMult * footRelief * chalkMult * wetMult * gustMult)
			gripStamina = math.clamp(gripStamina + netDelta * dt, 0, 100)

			if spec.BreakTime then
				looseHoldTimer += dt
				if looseHoldTimer > spec.BreakTime * 0.48 and looseHoldTimer - dt <= spec.BreakTime * 0.48 then
					showBannerFn("LOOSE ROCK FLAKE FRACTURING - MOVE HAND NOW!")
				end
				if looseHoldTimer >= spec.BreakTime then
					local snapped = currentHandHold
					looseHoldTimer = 0
					currentHandHold = nil
					gripStamina = math.max(38, gripStamina - 22)
					showBannerFn("FLAKE SNAPPED OFF! CAUGHT BY BELAY ROPE!")
					climbingEvent:FireServer("BreakLooseHold", snapped)
				end
			end
		end
	else
		gripStamina = math.clamp(gripStamina - 3.2 * stanceMult * dt, 0, 100)
	end

	if gripStamina <= 0 then
		gripStamina = 58
		currentHandHold = nil
		showBannerFn("FOREARMS PUMPED OUT - BELAY ROPE CAUGHT YOUR FALL!")
		climbingEvent:FireServer("FallToAnchor")
	end

	updateHUD()
end

return FirstPersonClimbClient
