--!strict
-- WaterfallDiveClient.luau
-- First-person waterfall swan-dive camera, ballistic arc, speed-FOV scaling,
-- mouse head-glance, A/D air-carve, rushing mist VFX, and underwater plunge recovery.

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
local UserInputService = game:GetService("UserInputService")
local Workspace = game:GetService("Workspace")

local localPlayer = Players.LocalPlayer
local camera = Workspace.CurrentCamera

local sideGameFolder = ReplicatedStorage:WaitForChild("WaterfrontSideGame")
local remotes = sideGameFolder:WaitForChild("Remotes")
local diveEvent = remotes:WaitForChild("WaterfallDiveEvent") :: RemoteEvent

local WaterfallDiveClient = {}

export type DivePayload = {
	StartPos: Vector3,
	ForwardDir: Vector3,
	TargetWaterY: number,
	PoolDepth: number,
	DiveName: string,
}

local activeDiving = false
local diveConn: RBXScriptConnection? = nil
local savedCameraMode = localPlayer.CameraMode
local savedCameraType = Enum.CameraType.Custom
local savedFOV = 70
local showBannerFn: (string) -> () = function() end

function WaterfallDiveClient.isDiving(): boolean
	return activeDiving
end

local fxPart = Instance.new("Part")
fxPart.Name = "FirstPersonDiveFX"
fxPart.Size = Vector3.new(1, 1, 1)
fxPart.Anchored = true
fxPart.CanCollide = false
fxPart.Transparency = 1
fxPart.Parent = Workspace

local rushMist = Instance.new("ParticleEmitter")
rushMist.Name = "RushByMist"
rushMist.Enabled = false
rushMist.Rate = 95
rushMist.Lifetime = NumberRange.new(0.18, 0.35)
rushMist.Speed = NumberRange.new(55, 95)
rushMist.EmissionDirection = Enum.NormalId.Back
rushMist.SpreadAngle = Vector2.new(26, 26)
rushMist.Size = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.35), NumberSequenceKeypoint.new(1, 2.8) })
rushMist.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.55), NumberSequenceKeypoint.new(1, 1) })
rushMist.Color = ColorSequence.new(Color3.fromRGB(228, 246, 255))
rushMist.Parent = fxPart

local plungeBubbles = Instance.new("ParticleEmitter")
plungeBubbles.Name = "UnderwaterPlungeBubbles"
plungeBubbles.Enabled = false
plungeBubbles.Rate = 160
plungeBubbles.Lifetime = NumberRange.new(0.45, 1.1)
plungeBubbles.Speed = NumberRange.new(12, 28)
plungeBubbles.SpreadAngle = Vector2.new(180, 180)
plungeBubbles.Size = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.45), NumberSequenceKeypoint.new(1, 0.1) })
plungeBubbles.Transparency = NumberSequence.new({ NumberSequenceKeypoint.new(0, 0.2), NumberSequenceKeypoint.new(1, 1) })
plungeBubbles.Color = ColorSequence.new(Color3.fromRGB(195, 242, 255))
plungeBubbles.Parent = fxPart

local windSound = Instance.new("Sound")
windSound.SoundId = "rbxassetid://9114223741"
windSound.Looped = true
windSound.Volume = 0
windSound.Parent = fxPart

local splashSound = Instance.new("Sound")
splashSound.SoundId = "rbxassetid://9112758529"
splashSound.Volume = 0.85
splashSound.Parent = fxPart

local function cleanupDiveState()
	if diveConn then
		diveConn:Disconnect()
		diveConn = nil
	end
	activeDiving = false
	rushMist.Enabled = false
	plungeBubbles.Enabled = false
	windSound:Stop()

	camera.FieldOfView = savedFOV
	camera.CameraType = savedCameraType
	localPlayer.CameraMode = savedCameraMode
	UserInputService.MouseBehavior = Enum.MouseBehavior.Default
end

local function runFirstPersonDive(payload: DivePayload)
	if activeDiving then
		return
	end
	local char = localPlayer.Character
	local hrp = char and char:FindFirstChild("HumanoidRootPart") :: BasePart?
	local hum = char and char:FindFirstChildOfClass("Humanoid")
	if not hrp or not hum then
		return
	end

	activeDiving = true
	savedCameraMode = localPlayer.CameraMode
	savedCameraType = camera.CameraType
	savedFOV = camera.FieldOfView

	localPlayer.CameraMode = Enum.CameraMode.LockFirstPerson
	camera.CameraType = Enum.CameraType.Scriptable
	UserInputService.MouseBehavior = Enum.MouseBehavior.LockCenter

	hum.PlatformStand = true
	hrp.Anchored = true

	local forward = Vector3.new(payload.ForwardDir.X, 0, payload.ForwardDir.Z).Unit
	local right = forward:Cross(Vector3.yAxis).Unit

	local curPos = payload.StartPos + Vector3.new(0, 2.8, 0) + forward * 2.5
	local horizSpeed = 24.0
	local vertVel = 15.0
	local lateralOffset = 0.0
	local lookYawOffset = 0.0
	local lookPitchOffset = 0.0
	local phase: "Airborne" | "Underwater" = "Airborne"
	local underwaterTimer = 0.0
	local elapsed = 0.0

	pcall(function()
		windSound.Volume = 0.1
		windSound.PlaybackSpeed = 0.85
		windSound:Play()
	end)
	showBannerFn(payload.DiveName .. " - FIRST-PERSON PLUNGE!")

	diveConn = RunService.RenderStepped:Connect(function(dt: number)
		if not hrp.Parent or not hum.Parent or hum.Health <= 0 then
			hrp.Anchored = false
			cleanupDiveState()
			return
		end

		elapsed += dt
		local mouseDelta = UserInputService:GetMouseDelta()
		lookYawOffset = math.clamp(lookYawOffset - mouseDelta.X * 0.0032, math.rad(-42), math.rad(42))
		lookPitchOffset = math.clamp(lookPitchOffset - mouseDelta.Y * 0.0028, math.rad(-26), math.rad(28))

		if phase == "Airborne" then
			local steer = (if UserInputService:IsKeyDown(Enum.KeyCode.D) then 1 else 0)
				- (if UserInputService:IsKeyDown(Enum.KeyCode.A) then 1 else 0)
			lateralOffset = math.clamp(lateralOffset + steer * 11.5 * dt, -5.0, 5.0)

			horizSpeed = math.max(2.2, horizSpeed * math.exp(-2.1 * dt))
			vertVel = math.max(-158, vertVel - 92.0 * dt)

			curPos += forward * (horizSpeed * dt) + Vector3.new(0, vertVel * dt, 0)
			local worldPos = curPos + right * lateralOffset

			local diveAlpha = math.clamp((elapsed - 0.12) / 0.72, 0, 1)
			local smoothAlpha = diveAlpha * diveAlpha * (3 - 2 * diveAlpha)
			local basePitch = math.rad(12) * (1 - smoothAlpha) + math.rad(-79) * smoothAlpha

			local fallFactor = math.clamp(-vertVel / 148, 0, 1)
			camera.FieldOfView = savedFOV + 6 + fallFactor * 30

			local buffetX = math.sin(elapsed * 37) * fallFactor * 0.008
			local buffetY = math.cos(elapsed * 43) * fallFactor * 0.008

			local bodyCF = CFrame.lookAt(worldPos, worldPos + forward) * CFrame.Angles(basePitch, 0, -steer * 0.18)
			hrp.CFrame = bodyCF * CFrame.Angles(math.rad(-90), 0, 0)

			local eyeCF = bodyCF
				* CFrame.new(0, 0.85, -0.6)
				* CFrame.Angles(lookPitchOffset + buffetX, lookYawOffset + buffetY, 0)
			camera.CFrame = eyeCF

			fxPart.CFrame = eyeCF * CFrame.new(0, 0, -5.5)
			rushMist.Enabled = fallFactor > 0.22
			rushMist.Rate = 40 + fallFactor * 115
			windSound.Volume = math.clamp(fallFactor * 0.95, 0.08, 0.95)
			windSound.PlaybackSpeed = 0.85 + fallFactor * 0.55

			if worldPos.Y <= payload.TargetWaterY then
				phase = "Underwater"
				rushMist.Enabled = false
				plungeBubbles.Enabled = true
				windSound:Stop()
				pcall(function()
					splashSound:Play()
				end)
				camera.FieldOfView = math.max(62, savedFOV - 8)
				diveEvent:FireServer("SplashdownImpact", Vector3.new(worldPos.X, payload.TargetWaterY, worldPos.Z))
			end
		else
			underwaterTimer += dt
			local maxPlungeY = payload.TargetWaterY - math.max(6, payload.PoolDepth - 2.5)

			if underwaterTimer < 0.55 then
				vertVel = math.min(-4, vertVel * math.exp(-5.8 * dt))
				curPos = Vector3.new(curPos.X, math.max(maxPlungeY, curPos.Y + vertVel * dt), curPos.Z)
			else
				vertVel = math.min(22, vertVel + 46 * dt)
				curPos += Vector3.new(0, vertVel * dt, 0)
			end

			local worldPos = curPos + right * lateralOffset
			local levelOut = math.clamp(underwaterTimer / 1.15, 0, 1)
			local pitch = math.rad(-79) * (1 - levelOut) + math.rad(-6) * levelOut
			camera.FieldOfView = camera.FieldOfView + (savedFOV - camera.FieldOfView) * math.min(1, dt * 5)

			local eyeCF = CFrame.lookAt(worldPos, worldPos + forward)
				* CFrame.Angles(pitch + lookPitchOffset * 0.5, lookYawOffset, 0)
			hrp.CFrame = CFrame.lookAt(worldPos, worldPos + forward)
			camera.CFrame = eyeCF
			fxPart.CFrame = eyeCF * CFrame.new(0, 0, -2.5)

			if underwaterTimer >= 0.75 and worldPos.Y >= payload.TargetWaterY + 1.2 then
				hrp.Anchored = false
				hrp.AssemblyLinearVelocity = forward * 8 + Vector3.new(0, 6, 0)
				hum.PlatformStand = false
				cleanupDiveState()
				diveEvent:FireServer("CompleteDive")
				showBannerFn("CLEAN WATERFALL ENTRY!")
			end
		end
	end)
end

function WaterfallDiveClient.init(bannerCallback: (string) -> ())
	showBannerFn = bannerCallback

	diveEvent.OnClientEvent:Connect(function(action: string, payload: DivePayload?)
		if action == "StartWaterfallDive" and payload then
			runFirstPersonDive(payload)
		end
	end)
end

return WaterfallDiveClient
