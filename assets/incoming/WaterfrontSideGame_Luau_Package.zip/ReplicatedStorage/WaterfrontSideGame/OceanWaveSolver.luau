--!strict
-- OceanWaveSolver.luau
-- 6-Component Spectral Gerstner + Shoaling Refraction + Plunging Shore Breakers +
-- Rock/Headland Clapotis Reflection + Multi-Group Deep-Sea Swell Sets + Orbital Velocity.

local WaterfrontConfig = require(script.Parent:WaitForChild("WaterfrontConfig"))

local OceanWaveSolver = {}

export type WaveSample = {
	height: number,
	displacement: Vector3,
	normal: Vector3,
	orbitalVelocity: Vector3,
	chop: number,
	breakerFoam: number,
	clapotis: number,
	zoneName: string,
	currentPush: Vector3,
	masked: boolean,
}

type WaveComponent = {
	dirX: number,
	dirZ: number,
	wavelength: number,
	amplitude: number,
	steepness: number,
	speedMult: number,
}

-- 6-band directional spectrum: primary swell rolls shoreward (+localZ) to aid natural navigation
local WAVE_SPECTRUM: { WaveComponent } = {
	{ dirX = 0.09,  dirZ = 0.996, wavelength = 104, amplitude = 2.15, steepness = 0.50, speedMult = 1.00 }, -- Dominant coastal swell
	{ dirX = -0.28, dirZ = 0.960, wavelength = 68,  amplitude = 1.30, steepness = 0.44, speedMult = 1.08 }, -- Secondary cross-swell
	{ dirX = 0.42,  dirZ = 0.907, wavelength = 42,  amplitude = 0.78, steepness = 0.40, speedMult = 1.18 }, -- Mid-band chop A
	{ dirX = -0.61, dirZ = 0.792, wavelength = 26,  amplitude = 0.46, steepness = 0.35, speedMult = 1.28 }, -- Mid-band chop B
	{ dirX = 0.81,  dirZ = 0.586, wavelength = 15,  amplitude = 0.26, steepness = 0.30, speedMult = 1.42 }, -- Wind ripple A
	{ dirX = -0.88, dirZ = 0.475, wavelength = 9.5, amplitude = 0.16, steepness = 0.25, speedMult = 1.56 }, -- Jagged surface texture
}

local GRAVITY = 32.0
local TWO_PI = math.pi * 2

local function smoothstep(edge0: number, edge1: number, x: number): number
	local t = math.clamp((x - edge0) / math.max(0.0001, edge1 - edge0), 0, 1)
	return t * t * (3 - 2 * t)
end

-- Evaluates shoaling surf factor (0..1), rock-wall clapotis reflection (0..1), and shoreward refraction target
local function evaluateBoundaryHydrology(lx: number, lz: number): (number, number, number, number)
	local shoreZ = WaterfrontConfig.getOuterShorelineZ(lx)
	local distToShore = math.max(0, shoreZ - lz)
	local surfBand = 1 - smoothstep(25, WaterfrontConfig.ZONES.SURF_BREAK_DEPTH, distToShore)

	local refractX, refractZ = 0.0, 1.0
	local halfW = WaterfrontConfig.BREAKWATER_HALF_WIDTH

	-- Clapotis bounce off the outer stone breakwater wall
	local breakwaterClapotis = 0
	if math.abs(lx) <= halfW + 10 and distToShore < 190 then
		breakwaterClapotis = (1 - smoothstep(10, 190, distToShore)) * 0.75
	end

	-- Utah flanking sandstone cliffs, arches & sea caves turbulence
	local headlandClapotis = 0
	if math.abs(lx) > halfW - 20 and lz > -1520 and lz < 160 then
		local intoFlank = smoothstep(halfW - 20, halfW + 190, math.abs(lx)) * (1 - smoothstep(-1180, -1520, lz))
		headlandClapotis = intoFlank * 0.95
		surfBand = math.max(surfBand, intoFlank * 0.85)
		refractX = math.sign(lx) * 0.65
		refractZ = 0.76
	end

	-- Clapotis rings around the two protruding stunt rocks
	for _, rSpec in WaterfrontConfig.ROCK_JUMPS do
		local dx = lx - rSpec.RockPos.X
		local dz = lz - rSpec.RockPos.Z
		local d = math.sqrt(dx * dx + dz * dz)
		if d < rSpec.RockWidth + 95 then
			local rockBounce = 1 - smoothstep(rSpec.RockWidth * 0.5, rSpec.RockWidth + 95, d)
			headlandClapotis = math.max(headlandClapotis, rockBounce * 0.9)
		end
	end

	-- Distant Island shoaling surf aprons
	local sPos = WaterfrontConfig.SMALL_ISLAND.LOCAL_POS
	local sDist = math.sqrt((lx - sPos.X) ^ 2 + (lz - sPos.Z) ^ 2)
	if sDist < WaterfrontConfig.SMALL_ISLAND.RADIUS + 280 then
		local sSurf = 1 - smoothstep(WaterfrontConfig.SMALL_ISLAND.RADIUS - 15, WaterfrontConfig.SMALL_ISLAND.RADIUS + 260, sDist)
		if sSurf > surfBand then
			surfBand = sSurf
			local inv = 1 / math.max(1, sDist)
			refractX = (sPos.X - lx) * inv
			refractZ = (sPos.Z - lz) * inv
		end
	end

	local bPos = WaterfrontConfig.BIG_ISLAND.LOCAL_POS
	local bDist = math.sqrt((lx - bPos.X) ^ 2 + (lz - bPos.Z) ^ 2)
	if bDist < WaterfrontConfig.BIG_ISLAND.BASE_RADIUS + 460 then
		local bSurf = 1 - smoothstep(WaterfrontConfig.BIG_ISLAND.BASE_RADIUS - 25, WaterfrontConfig.BIG_ISLAND.BASE_RADIUS + 430, bDist)
		if bSurf > surfBand then
			surfBand = bSurf
			headlandClapotis = math.max(headlandClapotis, bSurf * 0.78)
			local inv = 1 / math.max(1, bDist)
			refractX = (bPos.X - lx) * inv
			refractZ = (bPos.Z - lz) * inv
		end
	end

	local clapotis = math.clamp(math.max(breakwaterClapotis, headlandClapotis), 0, 1)
	return math.clamp(surfBand, 0, 1), clapotis, refractX, refractZ
end

function OceanWaveSolver.sample(worldX: number, worldZ: number, timeSec: number, lodLevel: number?): WaveSample
	local lod = lodLevel or 0
	local originCF = WaterfrontConfig.getOriginCFrame()
	local baseSeaY = originCF.Position.Y
	local localPos = originCF:PointToObjectSpace(Vector3.new(worldX, baseSeaY, worldZ))

	local lx = localPos.X
	local lz = localPos.Z
	local masked = WaterfrontConfig.isMaskedLandOrHarbor(lx, lz)

	local radialDist = math.sqrt(lx * lx + lz * lz)
	local zones = WaterfrontConfig.ZONES

	-- 1. Marina slip calmer pocket right beside the spawned watercraft finger piers
	local slipDist = math.sqrt(lx * lx + (lz + 145) * (lz + 145))
	local harborDamp = 0.22 + 0.78 * smoothstep(55, zones.HARBOR_RADIUS, slipDist)

	-- 2. Distance scaling: mild-to-moderate medium waves in coastal/stunt zone -> towering swells 1-3+ miles out
	local deepFactor = smoothstep(zones.STUNT_ZONE_END, zones.ABYSS_SWELL_START, radialDist)
	local cutoffFactor, cutoffPushLocal = WaterfrontConfig.getCutoffFactor(lx, lz)

	local ampScale = harborDamp * (0.94 + deepFactor * 3.05 + cutoffFactor * 2.45)
	local lengthScale = 1.0 + deepFactor * 1.40

	-- 3. Boundary shoaling refraction & cliff clapotis
	local surfFactor, clapotis, refX, refZ = evaluateBoundaryHydrology(lx, lz)
	surfFactor *= harborDamp
	clapotis *= harborDamp

	local dispX, dispY, dispZ = 0, 0, 0
	local dYdX, dYdZ = 0, 0
	local orbVx, orbVy, orbVz = 0, 0, 0

	local maxBands = if lod == 0 then 6 elseif lod == 1 then 4 else 2

	for i = 1, maxBands do
		local comp = WAVE_SPECTRUM[i]

		local bend = surfFactor * 0.45
		local dx = comp.dirX * (1 - bend) + refX * bend
		local dz = comp.dirZ * (1 - bend) + refZ * bend
		local invMag = 1 / math.max(0.001, math.sqrt(dx * dx + dz * dz))
		dx *= invMag
		dz *= invMag

		local wl = comp.wavelength * lengthScale * (1 - surfFactor * 0.34)
		local k = TWO_PI / wl
		local amp = comp.amplitude * ampScale
		if i >= 4 and (surfFactor > 0.1 or clapotis > 0.1) then
			amp *= (1 + surfFactor * 1.65 + clapotis * 1.55)
		end

		local omega = math.sqrt(GRAVITY * k) * comp.speedMult
		local phase = k * (dx * lx + dz * lz) - omega * timeSec
		local sinP = math.sin(phase)
		local cosP = math.cos(phase)

		local q = math.clamp(comp.steepness + surfFactor * 0.30, 0, 0.86) / (k * math.max(amp, 0.06) * maxBands)

		local vertProfile = sinP
		if surfFactor > 0.18 and sinP > 0 then
			local crestSkew = math.sin(phase + surfFactor * 0.42 * sinP)
			vertProfile = math.pow(math.max(0, crestSkew), 0.74)
		end

		dispX += q * amp * dx * cosP
		dispZ += q * amp * dz * cosP
		dispY += amp * vertProfile

		dYdX += k * amp * dx * cosP
		dYdZ += k * amp * dz * cosP

		orbVx += omega * amp * dx * sinP
		orbVz += omega * amp * dz * sinP
		orbVy -= omega * amp * cosP
	end

	-- 4. Deep-Ocean Multi-Group Swell Interference ("Wave Sets" beyond 1 mile)
	if deepFactor > 0.02 then
		local k1 = TWO_PI / 320
		local k2 = TWO_PI / 375
		local w1 = math.sqrt(GRAVITY * k1)
		local w2 = math.sqrt(GRAVITY * k2)
		local p1 = k1 * (0.22 * lx + 0.975 * lz) - w1 * timeSec
		local p2 = k2 * (-0.14 * lx + 0.990 * lz) - w2 * timeSec

		local a1 = (6.8 * deepFactor + 5.2 * cutoffFactor)
		local a2 = (5.4 * deepFactor + 4.0 * cutoffFactor)

		dispY += a1 * math.sin(p1) + a2 * math.sin(p2)
		dYdX += k1 * a1 * 0.22 * math.cos(p1) - k2 * a2 * 0.14 * math.cos(p2)
		dYdZ += k1 * a1 * 0.975 * math.cos(p1) + k2 * a2 * 0.990 * math.cos(p2)

		orbVz += w1 * a1 * math.sin(p1) + w2 * a2 * math.sin(p2)
	end

	-- 5. Reflected Rock Clapotis
	if lod == 0 and clapotis > 0.08 then
		local clapK = TWO_PI / 21
		local clapAmp = clapotis * 1.95
		local standing = math.sin(clapK * lx) * math.cos(clapK * lz) * math.cos(timeSec * 4.8)
		dispY += clapAmp * standing
		dYdX += clapK * clapAmp * math.cos(clapK * lx) * math.cos(clapK * lz) * math.cos(timeSec * 4.8)
		dYdZ -= clapK * clapAmp * math.sin(clapK * lx) * math.sin(clapK * lz) * math.cos(timeSec * 4.8)
	end

	-- 6. Jagged Whitewater Bore & Undertow Currents
	local chop = 0.14 + deepFactor * 0.58 + surfFactor * 1.75 + clapotis * 1.45
	if lod == 0 and surfFactor > 0.22 then
		local jag = math.sin(lx * 0.41 + timeSec * 8.2) * math.cos(lz * 0.46 - timeSec * 7.5)
		dispY += jag * surfFactor * 1.30
	end

	local localCurrent = Vector3.zero
	if surfFactor > 0.22 then
		local boreWave = math.sin(lz * 0.085 - timeSec * 2.55)
		local surgeStrength = if boreWave > 0 then boreWave * 19.5 else boreWave * 7.5
		localCurrent += Vector3.new(refX * surgeStrength * surfFactor, 0, refZ * surgeStrength * surfFactor)
	end
	if clapotis > 0.25 then
		localCurrent += Vector3.new(math.sin(timeSec * 1.9 + lz * 0.04), 0, math.cos(timeSec * 2.1 + lx * 0.04)) * (clapotis * 9.0)
	end
	if cutoffFactor > 0.005 then
		localCurrent += cutoffPushLocal * (cutoffFactor * 115)
	end

	local localNormal = Vector3.new(-dYdX, 1, -dYdZ).Unit
	local worldNormal = originCF:VectorToWorldSpace(localNormal)
	local worldDisp = originCF:VectorToWorldSpace(Vector3.new(dispX, dispY, dispZ))
	local worldOrbital = originCF:VectorToWorldSpace(Vector3.new(orbVx, orbVy, orbVz))
	local worldCurrent = originCF:VectorToWorldSpace(localCurrent)

	local zoneName = "CoastalStunt"
	if slipDist < zones.HARBOR_RADIUS then
		zoneName = "Harbor"
	elseif cutoffFactor > 0.05 then
		zoneName = "OuterCutoff"
	elseif deepFactor > 0.65 then
		zoneName = "AbyssalOcean"
	elseif deepFactor > 0.15 then
		zoneName = "DeepOcean"
	elseif surfFactor > 0.42 or clapotis > 0.45 then
		zoneName = "BreakingSurf"
	end

	local crestSteepness = math.clamp(1 - localNormal.Y, 0, 1)
	local breakerFoam = math.clamp(
		surfFactor * 0.82 + clapotis * 0.55 + crestSteepness * 2.1 + math.max(0, dispY / math.max(3.6, 4.8 * ampScale)) * 0.45,
		0,
		1
	)

	return {
		height = baseSeaY + dispY,
		displacement = worldDisp,
		normal = worldNormal,
		orbitalVelocity = worldOrbital,
		chop = chop,
		breakerFoam = breakerFoam,
		clapotis = clapotis,
		zoneName = zoneName,
		currentPush = worldCurrent,
		masked = masked,
	}
end

return OceanWaveSolver
