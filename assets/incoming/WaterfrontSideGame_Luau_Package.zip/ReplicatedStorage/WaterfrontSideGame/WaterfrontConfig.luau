--!strict
-- WaterfrontConfig.luau
-- Shared configuration for coastline/harbor masking, multi-mile ocean wave zones,
-- planetary curvature occlusion, 6-point watercraft hydrodynamics, stunt challenges,
-- distant islands, 3-point tactical rock climbing, and waterfall cliff diving.

local Workspace = game:GetService("Workspace")

local WaterfrontConfig = {}

-- Fallback if Workspace.WaterfrontOrigin is not yet placed on the outer lip of the stone breakwater
WaterfrontConfig.DEFAULT_ORIGIN_CFRAME = CFrame.new(0, 2, -350)

function WaterfrontConfig.getOriginCFrame(): CFrame
	local anchor = Workspace:FindFirstChild("WaterfrontOrigin")
	if anchor and anchor:IsA("BasePart") then
		local pos = anchor.Position
		local look = Vector3.new(anchor.CFrame.LookVector.X, 0, anchor.CFrame.LookVector.Z)
		if look.Magnitude < 0.001 then
			look = Vector3.new(0, 0, -1)
		else
			look = look.Unit
		end
		return CFrame.lookAt(pos, pos + look)
	end
	return WaterfrontConfig.DEFAULT_ORIGIN_CFRAME
end

function WaterfrontConfig.localToWorld(localPos: Vector3): Vector3
	return WaterfrontConfig.getOriginCFrame():PointToWorldSpace(localPos)
end

function WaterfrontConfig.worldToLocal(worldPos: Vector3): Vector3
	return WaterfrontConfig.getOriginCFrame():PointToObjectSpace(worldPos)
end

function WaterfrontConfig.localCFrameToWorld(localCF: CFrame): CFrame
	return WaterfrontConfig.getOriginCFrame():ToWorldSpace(localCF)
end

--------------------------------------------------------------------------------
-- SHORELINE & BREAKWATER SPATIAL MASKING
-- Protects the calm enclosed marina basin and sandy beach (+localZ) while
-- wrapping rough surf around the outer flanks and Utah sandstone headlands.
--------------------------------------------------------------------------------
WaterfrontConfig.BREAKWATER_HALF_WIDTH = 430

function WaterfrontConfig.getOuterShorelineZ(localX: number): number
	local halfW = WaterfrontConfig.BREAKWATER_HALF_WIDTH
	local absX = math.abs(localX)
	if absX <= halfW then
		-- Outer face of the grey stone breakwater sits right along localZ = 0
		return -2.0
	end
	local flankDist = absX - halfW
	return math.clamp(42 - flankDist * 0.08 + math.sin(localX * 0.018) * 22, -160, 58)
end

function WaterfrontConfig.isMaskedLandOrHarbor(localX: number, localZ: number): boolean
	local halfW = WaterfrontConfig.BREAKWATER_HALF_WIDTH
	if math.abs(localX) <= halfW and localZ > -2.0 then
		return true
	end
	if math.abs(localX) > halfW and localZ > WaterfrontConfig.getOuterShorelineZ(localX) + 14 then
		return true
	end
	return false
end

--------------------------------------------------------------------------------
-- MULTI-MILE OCEAN ZONES, PLANETARY CURVATURE & CUTOFF ENVELOPE
-- (~5,747 studs = 1 realistic mile scale)
--------------------------------------------------------------------------------
WaterfrontConfig.ZONES = {
	HARBOR_RADIUS = 230,                -- Sheltered slip pocket around the outer marina pier
	SURF_BREAK_DEPTH = 540,             -- Crashing asymmetric breaker band off shore & reefs
	STUNT_ZONE_END = 3800,              -- Mild-to-moderate medium waves across stunt course
	DEEP_OCEAN_START = 6000,            -- ~1+ mile out: long-period swells & wave sets begin
	ABYSS_SWELL_START = 16800,          -- ~3 miles out: huge open-ocean troughs hide the horizon
	MAINLAND_FADE_START = 7400,         -- Mainland begins sinking into planetary curvature
	MAINLAND_VANISH_DIST = 10200,       -- Mainland 100% lost below horizon before islands can appear
	EFFECTIVE_CURVATURE_RADIUS = 92000, -- Controls realistic hull-down / peak-first horizon rise

	-- Rectangular + Radial Outer Cutoff Envelope (~1.7 to 2.1 miles BEYOND both islands)
	SOFT_CUTOFF_Z = -38500,
	HARD_CUTOFF_Z = -41000,
	SOFT_CUTOFF_X = 26500,
	HARD_CUTOFF_X = 29000,
	SOFT_CUTOFF_START = 41500,
	HARD_CUTOFF_RADIUS = 44500,
}

-- Distant Islands: Positioned in separated outer-corner bearings so straight-out explorers miss both
WaterfrontConfig.SMALL_ISLAND = {
	LOCAL_POS = Vector3.new(-14800, 0, -18400), -- ~23,613 studs (~5.0 min drive, out & left)
	RADIUS = 210,
	DISCOVERY_RADIUS = 5800,
	MAX_BEARING_CONEDEG = 22,
	STREAM_PRELOAD_RADIUS = 7200,
}

WaterfrontConfig.BIG_ISLAND = {
	LOCAL_POS = Vector3.new(17200, 0, -28600),  -- ~33,373 studs (~7.0 min drive, far back & right)
	BASE_RADIUS = 960,
	TOTAL_HEIGHT = 485,
	LOOKOUT_HEIGHT = 360,
	CLIMB_START_HEIGHT = 360, -- Upper 1/4 sheer monolith spans Y = 360 -> 485 (125 studs)
	CHEST_LOCAL_OFFSET = Vector3.new(-248, 236, 118),
	DISCOVERY_RADIUS = 7800,
	MAX_BEARING_CONEDEG = 24,
	STREAM_PRELOAD_RADIUS = 9400,
}

-- Evaluates 0..1 outer boundary turnback intensity across the multi-mile ocean envelope
function WaterfrontConfig.getCutoffFactor(localX: number, localZ: number): (number, Vector3)
	local z = WaterfrontConfig.ZONES
	local overZ = math.clamp((-localZ - (-z.SOFT_CUTOFF_Z)) / ((-z.HARD_CUTOFF_Z) - (-z.SOFT_CUTOFF_Z)), 0, 1)
	local overX = math.clamp((math.abs(localX) - z.SOFT_CUTOFF_X) / (z.HARD_CUTOFF_X - z.SOFT_CUTOFF_X), 0, 1)
	local radial = math.sqrt(localX * localX + localZ * localZ)
	local overR = math.clamp((radial - z.SOFT_CUTOFF_START) / (z.HARD_CUTOFF_RADIUS - z.SOFT_CUTOFF_START), 0, 1)

	local factor = math.max(overZ, overX, overR)
	if factor <= 0.001 then
		return 0, Vector3.zero
	end

	local pushX = if math.abs(localX) > z.SOFT_CUTOFF_X then -math.sign(localX) * overX else -localX / math.max(1, radial) * overR
	local pushZ = if -localZ > -z.SOFT_CUTOFF_Z then overZ else -localZ / math.max(1, radial) * overR
	local pushDir = Vector3.new(pushX, 0, pushZ)
	if pushDir.Magnitude > 0.001 then
		pushDir = pushDir.Unit
	end
	return factor, pushDir
end

-- Computes planetary curvature vertical sink (studs) and visibility alpha for distant islands
function WaterfrontConfig.computeIslandVisibility(playerLocalPos: Vector3, islandType: "Small" | "Big"): (boolean, number, number)
	local zones = WaterfrontConfig.ZONES
	local distFromOrigin = Vector2.new(playerLocalPos.X, playerLocalPos.Z).Magnitude

	-- Strictly hidden until mainland shore has vanished behind the sea horizon
	if distFromOrigin < zones.MAINLAND_VANISH_DIST then
		return false, 1.0, -600
	end

	local spec = if islandType == "Small" then WaterfrontConfig.SMALL_ISLAND else WaterfrontConfig.BIG_ISLAND
	local delta2D = Vector2.new(playerLocalPos.X - spec.LOCAL_POS.X, playerLocalPos.Z - spec.LOCAL_POS.Z)
	local distToIsland = delta2D.Magnitude

	if distToIsland > spec.DISCOVERY_RADIUS then
		return false, 1.0, -600
	end

	local normalizedDist = math.max(0, distToIsland - 1400)
	local curvatureDrop = -(normalizedDist * normalizedDist) / (2 * zones.EFFECTIVE_CURVATURE_RADIUS)
	local hazeTransparency = math.clamp((distToIsland - (spec.DISCOVERY_RADIUS - 2200)) / 2200, 0, 1)

	return true, hazeTransparency, curvatureDrop
end

--------------------------------------------------------------------------------
-- 6-POINT HYDRODYNAMIC WATERCRAFT PROFILES
--------------------------------------------------------------------------------
export type VehicleProfile = {
	DisplayName: string,
	MaxSpeed: number,
	BoostBonus: number,
	Acceleration: number,
	PlaningSpeed: number,
	PlaningLift: number,
	ChineGrip: number,
	TurnSpeed: number,
	AirPitchTorque: number,
	AirRollTorque: number,
	BunnyHopImpulse: number,
	HullSize: Vector3,
	BuoyancyStiffness: number,
	BuoyancyDamping: number,
	WaveRoughnessSensitivity: number,
	PrimaryColor: Color3,
	AccentColor: Color3,
}

WaterfrontConfig.VEHICLES = {
	JetSki = {
		DisplayName = "Stunt Jet Ski",
		MaxSpeed = 80,
		BoostBonus = 18,
		Acceleration = 66,
		PlaningSpeed = 24,
		PlaningLift = 14.5,
		ChineGrip = 5.4,
		TurnSpeed = 2.75,
		AirPitchTorque = 4.0,
		AirRollTorque = 3.1,
		BunnyHopImpulse = 35,
		HullSize = Vector3.new(3.8, 2.2, 8.8),
		BuoyancyStiffness = 60,
		BuoyancyDamping = 7.8,
		WaveRoughnessSensitivity = 1.35,
		PrimaryColor = Color3.fromRGB(235, 68, 44),
		AccentColor = Color3.fromRGB(245, 245, 248),
	} :: VehicleProfile,

	WaveRunner = {
		DisplayName = "Ocean WaveRunner",
		MaxSpeed = 84,
		BoostBonus = 17,
		Acceleration = 54,
		PlaningSpeed = 28,
		PlaningLift = 13.0,
		ChineGrip = 4.8,
		TurnSpeed = 2.15,
		AirPitchTorque = 2.6,
		AirRollTorque = 2.0,
		BunnyHopImpulse = 23,
		HullSize = Vector3.new(4.6, 2.5, 10.6),
		BuoyancyStiffness = 64,
		BuoyancyDamping = 9.4,
		WaveRoughnessSensitivity = 0.95,
		PrimaryColor = Color3.fromRGB(24, 152, 212),
		AccentColor = Color3.fromRGB(250, 204, 42),
	} :: VehicleProfile,

	SpeedBoat = {
		DisplayName = "Offshore V-Hull Speedboat",
		MaxSpeed = 98,
		BoostBonus = 22,
		Acceleration = 38,
		PlaningSpeed = 34,
		PlaningLift = 16.5,
		ChineGrip = 4.1,
		TurnSpeed = 1.4,
		AirPitchTorque = 1.15,
		AirRollTorque = 0.85,
		BunnyHopImpulse = 0,
		HullSize = Vector3.new(8.5, 3.6, 22.0),
		BuoyancyStiffness = 72,
		BuoyancyDamping = 12.5,
		WaveRoughnessSensitivity = 0.58,
		PrimaryColor = Color3.fromRGB(242, 244, 248),
		AccentColor = Color3.fromRGB(22, 54, 118),
	} :: VehicleProfile,
}

-- Stunt Ring Ramp Challenges
WaterfrontConfig.RING_STUNTS = {
	{ Id = "RingStunt_Warmup",       RampPos = Vector3.new(-140, 0, -680),  YawDeg = 12,  RampLength = 34, RampAngleDeg = 21, RingDist = 48, RingHeight = 23, RingRadius = 8.5 },
	{ Id = "RingStunt_ThreadNeedle", RampPos = Vector3.new(210, 0, -1120),  YawDeg = -18, RampLength = 38, RampAngleDeg = 25, RingDist = 62, RingHeight = 31, RingRadius = 6.8 },
	{ Id = "RingStunt_DoubleCrest",  RampPos = Vector3.new(-320, 0, -1740), YawDeg = 25,  RampLength = 42, RampAngleDeg = 27, RingDist = 74, RingHeight = 36, RingRadius = 6.4 },
	{ Id = "RingStunt_HighFlyer",    RampPos = Vector3.new(95, 0, -2380),   YawDeg = -6,  RampLength = 46, RampAngleDeg = 29, RingDist = 84, RingHeight = 42, RingRadius = 6.0 },
}

-- Two Protruding Jagged Sea Rocks with Side Ramps
WaterfrontConfig.ROCK_JUMPS = {
	{ Id = "ProtrudingRock_West", RockPos = Vector3.new(-580, 0, -1380), RockHeight = 30, RockWidth = 26, RampOffset = Vector3.new(12, 0, 56),  RampYawDeg = 10,  RampAngleDeg = 28 },
	{ Id = "ProtrudingRock_East", RockPos = Vector3.new(640, 0, -1960),  RockHeight = 36, RockWidth = 32, RampOffset = Vector3.new(-14, 0, 64), RampYawDeg = -12, RampAngleDeg = 30 },
}

--------------------------------------------------------------------------------
-- TACTICAL 3-POINT FIRST-PERSON ROCK CLIMBING CONFIG
--------------------------------------------------------------------------------
export type HoldProfile = {
	DrainMult: number,
	RecoverRate: number,
	FootOnly: boolean?,
	CanPiton: boolean?,
	WetPenalty: number?,
	BreakTime: number?,
	Color: Color3,
	Size: Vector3,
}

WaterfrontConfig.CLIMBING = {
	MAX_HAND_REACH = 11.5,
	MAX_FOOT_REACH = 10.5,
	MIN_BODY_SPAN = 2.2,     -- Feet higher than this = bunched stance
	MAX_BALANCED_SPAN = 8.4, -- Hands higher than this above feet = overstretched
	HARD_BODY_SPAN = 11.8,   -- Must step feet up before reaching any higher
	STARTING_PITONS = 5,
	BASE_GRIP_DRAIN = 4.4,
	CHALK_DURATION = 11.0,
	CHALK_COOLDOWN = 14.0,
	GUST_PERIOD = 13.5,      -- Seconds between high-altitude crosswind gusts above Y = 410
	GUST_DURATION = 3.2,

	HOLD_TYPES = {
		Jug        = { DrainMult = 0.42, RecoverRate = 7.5,  Color = Color3.fromRGB(168, 162, 150), Size = Vector3.new(2.3, 0.95, 1.35) } :: HoldProfile,
		Ledge      = { DrainMult = 0.00, RecoverRate = 22.0, Color = Color3.fromRGB(146, 142, 134), Size = Vector3.new(4.8, 1.25, 2.30) } :: HoldProfile,
		Crimp      = { DrainMult = 2.15, RecoverRate = 0.0,  Color = Color3.fromRGB(116, 110, 106), Size = Vector3.new(1.55, 0.42, 0.65) } :: HoldProfile,
		Sloper     = { DrainMult = 1.65, RecoverRate = 0.0,  Color = Color3.fromRGB(136, 128, 120), Size = Vector3.new(2.1, 1.15, 1.05) } :: HoldProfile,
		WetSloper  = { DrainMult = 2.45, RecoverRate = 0.0,  WetPenalty = 1.75, Color = Color3.fromRGB(74, 96, 104), Size = Vector3.new(2.15, 1.1, 1.05) } :: HoldProfile,
		LooseRock  = { DrainMult = 1.45, RecoverRate = 0.0,  BreakTime = 2.2, Color = Color3.fromRGB(158, 110, 82), Size = Vector3.new(1.9, 0.9, 1.1) } :: HoldProfile,
		PitonCrack = { DrainMult = 0.88, RecoverRate = 2.5,  CanPiton = true, Color = Color3.fromRGB(64, 60, 58), Size = Vector3.new(0.65, 2.8, 0.85) } :: HoldProfile,
		FootChip   = { DrainMult = 0.25, RecoverRate = 4.0,  FootOnly = true, Color = Color3.fromRGB(132, 136, 124), Size = Vector3.new(1.25, 0.38, 0.75) } :: HoldProfile,
	},
}

return WaterfrontConfig
